#define PLUGGUI 1
#define AU 1
#define PluginGUIEditor AEffGUIEditor
#include "vstplugsquartz.h"

#include <Carbon/Carbon.h>
#include <AudioUnit/AudioUnit.h>
#include "vstgui.h"
