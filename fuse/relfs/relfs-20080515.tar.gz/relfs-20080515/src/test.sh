case $1 in
    match) echo ''
;;
    init) echo "create table log(message varchar(4096))"
;;
    *) echo "insert into log(message) values('$(date) - $*')"
;;
esac

