(*
  This file is part of the "RelFS" program.

  RelFS is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation (version 2 of the License).

  RelFS is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with RelFS.  See the file LICENSE.  If you haven't received
  a copy of the GNU General Public License, write to:

  Free Software Foundation, Inc.,
  59 Temple Place, Suite 330, Boston, MA
  02111-1307  USA

  Vincenzo Ciancia

  applejack at users.sf.net
  vincenzo_ml at yahoo.it
  ciancia at di.unipi.it
*)

open Unix
open Printf
open Fuse
open Index
open Indexes
open Util
open List
open Files
open Connection
open Unix_util

let setup_logging () =
  (* TODO: is this the right way to determine the home directory? *)
  let home = Unix.getenv "HOME" in
    handle_unix_error (fun _ ->
      try mkdir (home ^ ("/.relfs")) 0o700
    with Unix_error (EEXIST,_,_) -> ()) ();
    let (inp,out) = pipe () in
    match fork () with
	0 -> 
	  let cinp = in_channel_of_descr inp in
	  let uout = Unix.openfile (home ^ "/.relfs/log") [Unix.O_WRONLY; Unix.O_CREAT; Unix.O_APPEND] 0o666 in
	  let cout = out_channel_of_descr uout in
	    while true do
	      Printf.fprintf cout "%s\n%!" (input_line cinp);	      
	      if (stat (home ^ "/.relfs/log")).st_size  > 2000000
	      then (flush cout;
		    Sys.command "cp -f ~/.relfs/log ~/.relfs/log.old";
		    ftruncate uout 0;
		    Printf.fprintf cout "=== RELFS LOG ROTATED ===\n%!")
	    done
      | child_pid ->
	  Unix.dup2 out stdout;
	  Unix.close out;
	  log "=== RELFS RESTART ==="

let wrong_schema x =
  Printf.printf "detected wrong schema version: expected %s, found %s - exiting\n%!" Schema.version x;
  exit 0

let check_schema_version () =
  match Connection.createdb_and_open_connection () with
      None -> ()
    | Some version -> wrong_schema version

let relfs_operations dirhandle =
  { default_operations with
      
      (* Functions that do not interact with the database *)
      
      init = (fun () -> fchdir dirhandle);

      utime = log_op "utime" (local Unix.utimes);
      
      readlink = log_op "readlink" read_link;
      
      read = 
      log_op "read"
	(local (fun path buf offset hnd ->
	  let f = retrieve_file hnd in
	    ignore (LargeFile.lseek f.fd offset SEEK_SET);
	    Unix_util.read f.fd buf));
      
      write = 
      log_op "write"
	(local (fun path buf offset hnd -> (* TODO: the file has already been modified even if we ignore that until flush *)
	  let f = retrieve_file hnd in
	    ignore (LargeFile.lseek f.fd offset SEEK_SET);
	    Unix_util.write f.fd buf));
      
      (* TODO: check "if is_write_mode flags" and mark file as dirty somewhere so it will be checked in case of crash *)
      
      (* Functions that interact with the database *)
      
      fopen = log_op "fopen" open_file;
      readdir = log_op "readdir" get_dir;
      getattr = log_op "getattr" stat_file;
      mknod = log_op "mknod" create_file;
      mkdir = log_op "mkdir" create_dir;
      unlink = log_op "unlink" remove_file;
      rmdir = log_op "rmdir" remove_dir;	
      symlink = log_op_2str "symlink" create_symlink;
      rename = log_op_2str "rename" rename_ent;
      
      release = log_op "release" close_file;
      chmod = log_op_2int "chmod" change_mode;
      chown = log_op_2int "chown" change_owner;
      truncate = log_op "truncate" truncate_file; 

      listxattr = log_op "listxattr" ls_xattr;
      getxattr = log_op_2str "getxattr" get_xattr;
  (* TODO: to add the link operation, one needs to correct del_file in Files.ml and perhaps other functions
     link = create_link;
     
     let create_link src dst =
     with_lock mtx
     (fun () ->
     Unix.link (lpath src) (lpath dst); 
     main_index.on_link src dst;
  *)
  }

let main =
  let larg = Sys.argv.(Array.length Sys.argv - 1) in
  let directory = 
    if String.get larg 0 <> '/' 
    then (Unix.getcwd ()) ^ "/" ^ larg 
    else larg in
    
    (try chdir directory
     with Unix_error (e,_,x) -> 
       let barg = Filename.basename directory in
	 if (barg = "-h" or barg = "--help")
	 then Fuse.main [|Sys.argv.(0);"-h"|] default_operations
	 else printf "%s: %s\n(try --help or -h for optional arguments)\n%!" x (error_message e);
	 exit 0);

    check_schema_version ();
    main_index.on_init ();

    setup_logging ();

(* TODO:
   save_dir = open(DIR, O_RDONLY);

   And from the init() method do
   
   fchdir(save_dir); close(save_dir); *)

    let fuse_additional_args = [|"-f"; "-o"; "default_permissions,nonempty";"-d"|] in

      Fuse.main (Array.concat [[| Sys.argv.(0) |];
			       fuse_additional_args;
			       Array.sub Sys.argv 1 ((Array.length Sys.argv) - 2);
			       [| directory |]])
	(relfs_operations (Unix.openfile "." [O_RDONLY] 0))

