(*
  This file is part of the "RelFS" program.

  RelFS is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation (version 2 of the License).

  RelFS is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with RelFS.  See the file LICENSE.  If you haven't received
  a copy of the GNU General Public License, write to:

  Free Software Foundation, Inc.,
  59 Temple Place, Suite 330, Boston, MA
  02111-1307  USA

  Vincenzo Ciancia

  applejack at users.sf.net
  vincenzo_ml at yahoo.it
  ciancia at di.unipi.it
*)

open Thread
open Event

type index =
    { on_init : unit -> unit; (* called once before main *)
      on_modify : int -> unit;
      on_file : int -> unit;
      on_dir : int -> unit;
      on_link : int -> unit;
      on_symlink : int -> unit;
      on_rename : int -> unit;
      on_stat_change : int -> unit; }

let nop : 'a -> 'b = fun _ -> raise (Invalid_argument "noop called") (* This is actually never called *)

let default_index =
  { on_init = nop;
    on_modify = nop;
    on_file = nop;
    on_dir = nop;
    on_link = nop;
    on_symlink = nop;
    on_rename = nop;
    on_stat_change = nop; }

let modify_q = Queue.create ()
let file_q = Queue.create ()
let dir_q = Queue.create ()
let link_q = Queue.create ()
let symlink_q = Queue.create ()
let rename_q = Queue.create ()
let stat_change_q = Queue.create ()
let init_q = Queue.create ()

let pairs index =
  [(index.on_modify!=nop,modify_q);
   (index.on_file!=nop,file_q);
   (index.on_dir!=nop,dir_q);
   (index.on_link!=nop,link_q);
   (index.on_symlink!=nop,symlink_q);
   (index.on_rename!=nop,rename_q);
   (index.on_stat_change!=nop,stat_change_q)]

let add_index index = 
  List.iter (fun (present,queue) -> 
	       if present then Queue.add index queue) 
    (pairs index);
  if index.on_init != nop then Queue.add index.on_init init_q

let queue_remove x q =
  let tmp = Queue.create () in
    Queue.transfer q tmp;
    while not (Queue.is_empty tmp) do
      let v = Queue.pop tmp in
	if v!=x
	then Queue.add v q
    done

let remove_index index = List.iter (fun (present,queue) -> 
				      if present then queue_remove index queue) 
			   (pairs index)

let indexer chan =
  while true do
    sync (receive chan) ()
  done

let indexer_chan = new_channel ()

let indexer_thread = Thread.create indexer indexer_chan

let async_proxy inp out =
  let q = Queue.create () in
    while true do
      if Queue.is_empty q
      then Queue.add (sync (receive inp)) q
      else select [wrap (receive inp) (fun i -> Queue.add i q);
		   wrap (send out (Queue.top q)) (fun () -> ignore (Queue.pop q))]
    done

let proxy_chan = new_channel ()

let proxy_thread = Thread.create (async_proxy proxy_chan) indexer_chan

let send_operation op arg =
  sync (send proxy_chan (fun () -> op arg))

let queue_iter fn q = Queue.iter (fun x -> try fn x with _ -> ()) q

(* TODO: FILTER ON MATCH_FILE *)
let main_index = 

    { on_init = (fun () -> queue_iter (fun f -> f ()) init_q);

      on_modify = (fun id -> queue_iter (fun idx -> send_operation idx.on_modify id) modify_q);

      on_file = (fun id -> queue_iter (fun idx -> send_operation idx.on_file id) file_q);

      on_dir = (fun id -> queue_iter (fun idx -> send_operation idx.on_dir id) dir_q);

      on_link = (fun id -> queue_iter (fun idx -> send_operation idx.on_link id) link_q);

      on_symlink = (fun id -> queue_iter (fun idx -> send_operation idx.on_symlink id) symlink_q);

      on_rename = (fun id -> queue_iter (fun idx -> send_operation idx.on_rename id) rename_q);

      on_stat_change = (fun id -> queue_iter (fun idx -> send_operation idx.on_stat_change id) stat_change_q); }

(* Should become: 

   on_init

   on_create
   on_modify   
   on_stat_change

   remove

   no rename, because indexing must be based on object id, not path


   Also, add a match operation which is a where clause, returned by on_init
*)
