(*
  This file is part of the "RelFS" program.

  RelFS is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation (version 2 of the License).

  RelFS is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with RelFS.  See the file LICENSE.  If you haven't received
  a copy of the GNU General Public License, write to:

  Free Software Foundation, Inc.,
  59 Temple Place, Suite 330, Boston, MA
  02111-1307  USA

  Vincenzo Ciancia

  applejack at users.sf.net
  vincenzo_ml at yahoo.it
  ciancia at di.unipi.it
*)

external generate_and_unparse : unit -> string = "uuid_generate_and_unparse"

let minus = Pcre.regexp "-"

let make () = Pcre.replace ~rex:minus (generate_and_unparse ())
