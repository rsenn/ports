open Util
open Opt
open Postgresql
open Connection
open Filename
open Printf
open Unix
open LargeFile
open Index
open Mimetype

type file_data = { fd : Unix.file_descr;
		   id : int }

(* Path <-> id mapping *)
  
let lookup path = Opt.map int_of_string (exec1 (sprintf "select lookup('%s')" (escape_string path)))

let pathof id = exec1 (sprintf "select pathof(%d)" id)

(* A cache of open files *)

let open_files = Hashtbl.create 10000
let open_files_mut = Mutex.create ()

let store_file f = 
  let res = Unix_util.int_of_file_descr f.fd in
    with_lock open_files_mut
      (fun () -> Hashtbl.replace open_files res f);
    res

let retrieve_file i = 
 with_lock open_files_mut
   (fun () -> Hashtbl.find open_files i)

let forget_file i =
 with_lock open_files_mut
   (fun () -> Hashtbl.remove open_files i)

let update_file id path = (* TODO: update just what's needed *)
  let st = lstat (lpath path) in    
    ignore_exec (sprintf "update obj set kind='%c',perm='%s',uid=%d,gid=%d,size=%Lu,atime='%s',mtime='%s',ctime='%s' where id=%d"
		   (db_kind st.st_kind) (db_perm st.st_perm) st.st_uid st.st_gid st.st_size 
		   (db_time st.st_atime) (db_time st.st_mtime) (db_time st.st_ctime) id)

(**************************)

(** Given a path, adds this to the database, and returns the new index. Assumes that the file already exists on the filesystem *)
let add_file path =
  let dir = dirname path in
  let base = basename path in
  let st = lstat (lpath path) in (* TODO: could be avoided in case of getattr *)
  let res = transact
    (fun () ->
       match lookup dir with
	   None -> raise (Unix_error (ENOENT,"add_obj",path)) (* Can't happen.  TODO: define relfs-specific errors and log *)
	 | Some parent ->
	     let query = sprintf 
	       "insert into obj(name,kind,perm,uid,gid,size,atime,mtime,ctime) \
                         values('%s','%c',%s,%d,%d,%Lu,'%s','%s','%s')" 
	       (escape_string base) (db_kind st.st_kind) (db_perm st.st_perm)
	       st.st_uid st.st_gid st.st_size 
	       (db_time st.st_atime) (db_time st.st_mtime) (db_time st.st_ctime) in
	     let child_oid = 
	       (exec query)#oid_value in
	     let child = (exec (sprintf "select id from obj where oid=%d" child_oid))#getvalue 0 0 in
	       ignore_exec (sprintf "insert into membership(parent,child) values(%d,%s)" parent child);
	       int_of_string child)
  in
    (match st.st_kind with
	 S_REG -> main_index.on_file res
       | S_DIR -> main_index.on_dir res
       | S_LNK -> main_index.on_symlink res);
    res

let del_file path = (* TODO: it does not work if hardlinks are implemented because we should count references *)
  transact 
    (fun () ->
       match lookup path with
	   None -> ()
	 | Some id ->
	     ignore_exec (sprintf "delete from membership where child=%d" id);
	     ignore_exec (sprintf "delete from obj where id=%d" id))

let mtx = Mutex.create () (* Used to avoid separate lookups and additions in the database *)
  (* TODO: lock with single-file granularity; also, lookups are
     serialized if we do things this way, keep in mind when we
     will have multiple connections or this will become a
     bottleneck *) 

(* Operations that do not modify the filesystem *)

type query_result = QFile of (int * string) | QDir | QNone

let reg = Pcre.regexp "^.*/#([^/#]*)(|/.*)$" 
let perc = Pcre.regexp "%%" 
let slash = Pcre.subst "/"

let level path =
  let x = ref 1 in
    String.iter (function '/' -> x:=!x+1 | _ -> ()) path;
    !x

(*
let split_dir =
  (* given a path, obtains the first directory in the path (if the
     path is absolute, then the first directory is "") and the remaining
     relative path *)
  let first = Pcre.regexp "^([^/]*)/(.*)" in
    fun path ->
      let x = Pcre.extract ~full_match:false ~rex:first path in
	(x.(0),x.(1))

*)
    
let disambiguate lst =

  let repl s a b =
    let s1 = String.copy s in
      for i = 0 to (String.length s1) - 1 do
	if String.unsafe_get s1 i = a 
	then String.unsafe_set s1 i b
      done;
      s1 in

  let get_path path pathof =
    let dir = Filename.dirname pathof in
    let dir2 = try String.sub dir 1 (String.length dir - 1) with Invalid_argument _ -> "" in
      (*  let (name,suffix) = split_suffix path in *)
      if dir = "/" then path else 
	sprintf "[%s] %s" (repl dir2 '/' '#') path in

  List.fold_left (fun res x ->
		    match x with
		      | [a] -> a::res 
		      | _ -> 
			  List.append 
			    (List.map 
			       (function (id::path::pathof::is_reg::tl) -> 
				  id::(get_path path pathof)::pathof::is_reg::tl) x)
			    res) []
    (group_by (fun a b -> match (a,b) with (_::path1::_,_::path2::_) -> compare path1 path2) lst) 

let query_lst = 
  cache 3.0
    (fun path ->
       try
	 let [|query;child|] = Pcre.extract ~full_match:false ~rex:reg path in
	 let query = Pcre.replace ~rex:perc ~itempl:slash query in
	 let cmd = sprintf (* This query will never allow a single / to be returned (we wouldn't know how to deal with that) *)
	   (* leave_duplicated_tag is used to avoid leaving duplicates for directories, but to allow duplicates for files which 
	      will be disambiguated in this function *)
	   "select distinct on (path,leave_duplicated_tag) 
              id,path,pathof(id) as pathof,
              int_of_bool(leave_duplicated_tag <> 0) as is_reg from \
          (select s.id,\
                  case (length(split_part(path,'/',%d)) > 0) when true then 0 else s.id end as leave_duplicated_tag,
                  split_part(path,'/',%d) as path \
           from (%s) as s inner join obj o on o.id=s.id \
           where path like '%s/%%' escape '_' and (o.kind='r' or o.kind='l')) as subq1 \
         where path <> '/' and path <> ''" 
	   (level path + 1) (level path) query (escape_like child) in
	   let result = exec cmd in
	     if result#ntuples > 0	
	     then disambiguate result#get_all_lst
	     else raise (Unix_error (ENOENT,"query_dir",path))
       with Not_found -> raise (Unix_error (ENOENT,"query_dir",path)))
    
let query_dir path =
  Filename.current_dir_name::Filename.parent_dir_name::(List.map (function _::y::_ -> y) (query_lst path))

let query path =
  try
    let dir = Filename.dirname path in
    let file = Filename.basename path in
      if dir = "/" 
      then (if [] <> query_lst path
	    then QDir
	    else QNone)
      else 
	let lst = query_lst dir in
	let s_id::_::pathof::s_is_reg::_ = List.find (function _::y::_ -> y=file) lst in
	  if int_of_string s_is_reg == 0
	  then QDir
	  else QFile (int_of_string s_id,pathof)
  with Not_found -> QNone

let stat_file path =
  with_lock mtx
    (fun () ->
       try
	 let res = lstat (lpath path) in
	   (match lookup path with
		None -> ignore (add_file path)
	      | Some x -> ());  (* TODO: Here we should update stat information on the db, and mark file as "up-to-date on the db" *)
	   res
       with
	   Unix_error (ENOENT,_,_) as err -> (* Let's see if it's a query *)
	     match query path with
		 QNone -> raise err
	       | QFile (_,path) -> lstat (lpath path)
	       | QDir -> let x = lstat "." in {x with st_nlink=1;st_perm=x.st_perm land 0o7555 }) 
    (* TODO in QDir case: 

       - proper statistics including some mtime hack 

       - this method is slow when stat is called on a directory containing
       many symlinks to queries; we should detect if stat is called on the
       root directory of a query, and return the default result (lstat ".")
       without calling the query. This would be incorrect in case of queries
       generating errors in the DB, but would be much faster. Or else, using
       views or prepared queries or functions in place of direct "select",
       and calling them by name, we will avoid this problem. *)

let get_dir path _ =
  (* TODO: in readdir check if the dir corresponds to the membership information on the db here like in getattr for files *)
  try     
    [".";".."] @ 
      (Array.to_list 
	 (try Sys.readdir (lpath path) (* TODO: implement atime change in directories *)	   
	  with Sys_error _ -> 
	    raise (Unix_error (ENOENT,"get_dir",path)))) (* TODO: true unix readdir *)
  with Unix_error (ENOENT,_,_) -> query_dir path

let open_file path flags =
  with_lock mtx
    (fun () ->
       try
	 { fd = (let st = lstat (lpath path) in
		   if st.st_perm land 0o200 = 0 && is_write_mode flags
		   then 
		     try 
		       chmod (lpath path) (st.st_perm lor 0o200);
		       let fd = openfile (lpath path) flags 0 in
			 chmod (lpath path) st.st_perm;
			 fd
		     with e -> 
		       chmod (lpath path) st.st_perm;
		       raise e
		   else openfile (lpath path) flags 0);
	   id = match lookup path with
	       None -> add_file path 
	     | Some id -> id }
       with 
	   Unix_error (ENOENT,_,_) as err ->
	     match query path with
		 QNone -> raise err
	       | QDir -> raise (Unix_error (EISDIR,"open_file","path"))
	       | QFile (id,path) -> 
		   { fd=Unix.openfile (lpath path) flags 0;
		     id=id })

(* Operations that modify the filesystem - note that semantics is
slightly wrong, we should lookup and add transactionally - but I am
unsure of this since there already is locking *)

let create_file path mode =
  with_lock mtx
    (fun () ->
       close (openfile (lpath path) [O_CREAT;O_EXCL] mode);
       ignore (add_file path))

let create_dir path mode =
  with_lock mtx
    (fun () ->
       Unix.mkdir (lpath path) mode;
       ignore (add_file path))

let create_symlink src dst =
  with_lock mtx
    (fun () ->
       Unix.symlink src (lpath dst);
       ignore (add_file dst))

let remove_file path =
  with_lock mtx
    (fun () ->
       Unix.unlink (lpath path);
       del_file path)

let remove_dir path =
  with_lock mtx
    (fun () ->
       Unix.rmdir (lpath path);
       del_file path)

let rename_ent src dst =
  let id = with_lock mtx
    (fun () ->
       transact 
	 (fun () ->
	    try
	      let id = unopt (lookup src) in
	      let new_name = basename dst in
	      let old_dir_id = unopt (lookup (dirname src)) in
	      let new_dir_id = unopt (lookup (dirname dst)) in
		if (basename src) <> new_name
		then ignore_exec (sprintf "update obj set name='%s' where id=%d;" new_name id);
		if old_dir_id <> new_dir_id
		then ignore_exec (sprintf "update membership set parent=%d where parent=%d and child=%d" new_dir_id old_dir_id id);
		Unix.rename (lpath src) (lpath dst);
		update_file id dst;
		id
	    with Not_found -> 
	      raise (Unix_error (ENOENT,"rename_ent","")))) in
    main_index.on_rename id

let change_mode path mode =
  match 
    with_lock mtx
      (fun () ->
	 try
	   match (lstat (lpath path)).st_kind with
	       S_LNK -> None
	     | _ -> 
		 Unix.chmod (lpath path) mode;
		 match lookup path with
		     None -> Some (add_file path)
		   | Some id as i -> update_file id path;i	
	 with
	     Unix_error (ENOENT,_,_) as err -> (* Let's see if it's a query *)
	       match query path with
		   QNone -> raise err
		 | QFile (id,path) -> 
		     (match (lstat (lpath path)).st_kind with
			  S_LNK -> None
			| _ -> Unix.chmod (lpath path) mode;Some id)
		 | QDir -> raise (Unix_error (EPERM,"change_mode",path)))
  with 
      None -> ()
    | Some id -> main_index.on_stat_change id 

let change_owner path uid gid =
  main_index.on_stat_change
    (with_lock mtx
       (fun () ->
	  try
	    match (lstat (lpath path)).st_kind with
		S_LNK -> raise (Unix.Unix_error (ENOSYS,"chown",path)) (* TODO: ocaml is missing lchown *)
	      | _ ->
		  Unix.chown (lpath path) uid gid;
		  match lookup path with
		      None -> add_file path
		    | Some id -> update_file id path;id
	  with
	      Unix_error (ENOENT,_,_) as err -> (* Let's see if it's a query *)
		match query path with
		    QNone -> raise err
		  | QFile (id,path) -> 
		      (match (lstat (lpath path)).st_kind with
			   S_LNK -> raise (Unix.Unix_error (ENOSYS,"chown",path))
			 | _ -> Unix.chown (lpath path) uid gid;id)
		  | QDir -> raise (Unix_error (EPERM,"change_owner",path))))
       
let truncate_file path length =
  main_index.on_modify
    (with_lock mtx
       (fun () ->
	  try
	    truncate (lpath path) length;
	    match lookup path with
		None -> add_file path
	      | Some id -> update_file id path;id    
	  with
	      Unix_error (ENOENT,_,_) as err -> (* Let's see if it's a query *)
		match query path with
		    QNone -> raise err
		  | QFile (id,path) -> truncate (lpath path) length;id		      
		  | QDir -> raise (Unix_error (EPERM,"truncate_file",path))))

let open_file path flags = Some (store_file (open_file path flags))

let close_file path flags hnd =
  let f = retrieve_file hnd in
    Unix.close f.fd;
    forget_file hnd;
    update_file f.id path; (* For atime and mtime *)
    if is_write_mode flags
    then main_index.on_modify f.id

let list_attributes_outside_obj_table = 
  cache 3.0 
    (fun (schema,table,column,obj) ->
       exec (sprintf "select * from %s.%s where %s = %d" schema table column obj))

let get_xattr = 
  let att_reg = Pcre.regexp "^(user|relfs)(\\.([^.]*))?(\\.([^.]*))?\\.([^.]*)$" in
    (fun path attname ->
       let [|_;_;a;_;b;column|] = Pcre.extract ~full_match:false ~rex:att_reg attname in
       let schema = if b = "" then "public" else a in
       let table = 
	 if a = "" 
	 then "obj" 
	 else if b = "" then a else b in
       let (id,is_query_dir) = match lookup path with  (* TODO: duplicated code here and in lsxattr *)
	   None -> (match query path with
			QFile (id,_) -> (id,false)
		      | QDir -> (~-1,true)
		      | QNone -> (add_file path,false))
	 | Some id -> (id,false) in
	 if is_query_dir
	 then ""
	 else String.concat "," (List.map List.hd ((exec (sprintf "select %s from %s.%s where id=%d" column schema table id))#get_all_lst)))
	     
let all_attr = 
  (* this actually selects two different things: attributes on obj and
     fkeys named "id" and pointing to obj.id in other tables, for
     efficiency's sake *)

  (* TODO: define an "id" type and use that instead of the fkey constraint search,
     so that we will be able to also catch views *)
  cache 10.0 
    (fun () -> exec       
       (sprintf 
	  "select table_schema,table_name,column_name
            from information_schema.referential_constraints
                     natural join information_schema.key_column_usage
                where constraint_schema='public'
                      and unique_constraint_name='pk_obj_id'
                      and column_name = 'id'
              union
              select table_schema,table_name,column_name 
                from information_schema.columns
                where table_schema='public'
                      and table_name='obj'"))

let ls_xattr path = (* TODO: should we escape schema, table and column names? *)
  
  let print_attr schema table column =
    if schema = "public"
    then sprintf "relfs.%s.%s" table column
    else sprintf "relfs.%s.%s.%s" schema table column in

  let get_attrs schema table column obj res =
    let v=list_attributes_outside_obj_table (schema,table,column,obj) in
      if v#ntuples <= 0
      then res
      else List.fold_left (fun res col -> 
			     if col = column 
			     then res
			     else (print_attr schema table col)::res)
	res v#get_fnames_lst in
    
  (* lsxattr implementation starts here *)
  
  let (id,is_query_dir) =
    match lookup path with (* TODO: define a function for this frequently used bit of code *)
	None -> (match query path with
		     QFile (id,_) -> (id,false)
		   | QDir -> (~-1,true)
		   | QNone -> (add_file path,false))
      | Some id -> (id,false) in
    if is_query_dir
    then []
    else List.fold_left 
      (fun res data ->
	 match data with
	     (schema::table::column::tl) ->
	       if schema = "public" & table = "obj"
	       then (sprintf "user.%s" column)::res
	       else get_attrs schema table column id res)
      [] (all_attr ())#get_all_lst

let read_link path =
        try Unix.readlink (lpath path) with
                Unix_error (_,_,_)  -> match query path with
                       QNone -> raise (Unix_error (ENOENT,"readlink",path))
                       |QDir -> raise (Unix_error (ENOENT,"readlink",path))
                       |QFile(id,_) -> match pathof id with
                                None -> raise (Unix_error (ENOENT,"readlink",path)) 
                                | Some full_path -> 
                                                absolutize_link (lpath full_path)

