#include <libgnomevfs/gnome-vfs.h>

char * mimetype(char * file)
{
  return (char *)gnome_vfs_get_file_mime_type(file,NULL,FALSE);
}
