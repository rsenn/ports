(*
  This file is part of the "RelFS" program.

  RelFS is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation (version 2 of the License).

  RelFS is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with RelFS.  See the file LICENSE.  If you haven't received
  a copy of the GNU General Public License, write to:

  Free Software Foundation, Inc.,
  59 Temple Place, Suite 330, Boston, MA
  02111-1307  USA

  Vincenzo Ciancia

  applejack at users.sf.net
  vincenzo_ml at yahoo.it
  ciancia at di.unipi.it
*)

open Index
open Unix
open Filename
open Printf
open Postgresql
open Connection
open Util
open Files
open List

(* TODO:

  - add "unique" to "id" in "obj"

  - add cascade delete clauses

   FOR SQL IMPROVEMENTS
   
   - Separate type for quoted and unquoted strings
*)


(*
  A very simple indexer that runs idx every time something is added or changed, 
  and ren every time something is renamed
*)

let reindexer idx ren = 
  { default_index with
      on_modify = idx;
      on_file = idx;
      on_dir = idx;
      on_link = idx;
      on_symlink = idx;
      on_rename = ren;
      on_stat_change = idx; }

(* Index for file mimetypes *)

let add_file_mimetype id =
  try
    transact (fun () ->
		match pathof id with
		    None -> raise Rollback
		  | Some path ->
		      ignore_exec 
			(sprintf "delete from obj_mimetype where id=%d;insert into obj_mimetype(id,mimetype) values(%d,'%s')"
			   id id (Mimetype.mimetype (lpath path))))
  with _ -> ()

let del_file_mimetype id =
  ignore_exec (sprintf "delete from obj_mimetype where id=%d" id)

let _ = add_index (reindexer add_file_mimetype (fun x -> del_file_mimetype x; add_file_mimetype x))

(*****************************)

let read_all_output chan =  
  let buf = Buffer.create 4096 in
    try
      while true do
	Buffer.add_string buf (input_line chan);
      done;
      buf
    with End_of_file -> buf

let get_cmd_reply cmd options =
  try    
    let chan = (open_process_in (cmd ^ " " ^ (String.concat " " (map Filename.quote options)))) in
    let result = read_all_output chan in
      match close_process_in chan with
	  WEXITED 0 -> Some (Buffer.contents result)
	| _ -> None
  with _ -> None

(* TODO: on request, replace some kind of text e.g. {...} with a quoted string for the SQL server
   e.g. to avoid filename attacks on the db *)
let run_cmd_indexer cmd options =
  try 
    transact 
      (fun () -> 
	 match get_cmd_reply cmd options with
	     None -> raise Rollback
	   | Some query ->
	       let res = exec query in
		 (match res#status with
		      Command_ok -> ()
		    | _ -> raise Rollback))
  with _ -> ()
      
(* An indexer which calls cmd operation filename if file matchs the result of "cmd match" 

(* TODO: get supported and unsupported operations *)
let add_cmd_indexer cmd = 
  match get_cmd_reply cmd ["match"] with
      None -> ()

    | Some rexp ->
	let reg = regexp rexp in
	  add_index	  
	    { default_index with
		on_init = (fun () -> run_cmd_indexer cmd ["init"]);
		match_file = (fun path -> string_match reg path 0);
		on_modify = (fun path -> run_cmd_indexer cmd ["modify";path]);
		on_file = (fun path -> run_cmd_indexer cmd ["file";path]);
		on_dir = (fun path -> run_cmd_indexer cmd ["dir";path]);
		on_link = (fun src dest -> run_cmd_indexer cmd ["link";src;dest]);
		on_symlink = (fun src dest -> run_cmd_indexer cmd ["symlink";src;dest]);
		on_rename = (fun src dest -> run_cmd_indexer cmd ["rename";src;dest]);
		on_delete = (fun path -> run_cmd_indexer cmd ["delete";path]);
		on_stat_change = (fun path -> run_cmd_indexer cmd ["stat_change";path]) }
  
 let _ = add_cmd_indexer (Filename.concat (dirname Sys.executable_name) "test.sh") *)

