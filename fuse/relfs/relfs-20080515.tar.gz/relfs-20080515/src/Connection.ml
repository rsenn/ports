open Thread
open Event
open Postgresql
open Util

exception Rollback

(** 
    This module holds all functions related to database connection.
*)

let chan = new_channel ()
	    
(* Run a function on the main connection, in the same thread that created
   the connection in order to avoid locking, ignoring the result *)
let sql = fun x -> sync (send chan x)

(* Run a function on the connection, in the same thread that created
   the connection, and return the result *)
let run op = 
  let res = new_channel () in
    sql (fun conn -> sync (send res (op conn)));
    sync (receive res)

(* Public functions *)

(** Execute a database command and returns the result as a Postgresql.result value *)
let exec str =
  run (fun conn -> 
	 let res = (conn :> Postgresql.connection)#exec str in 
	   match res#status with
	       (Bad_response|Nonfatal_error|Fatal_error) ->
		 log res#error;
		 res
	     | _ -> res)

(** Execute a database command ignoring the result *)
let ignore_exec str =
  ignore (exec str)
(* NOTE: this function was previously implemented as:

   sql (fun conn -> ignore (conn#exec str)) 

   but this is asynchronous w.r.t. the calling thread, so any
   exception is thrown in the worker thread and the caller has no way
   to catch exceptions
*)

(**
   Takes an SQL command, and returns None in case of failure, and Some
   s, where s is the result string, in case of success.

   This is plain wrong, since Null is returned both for the error case and for
the case when there is no result. Exceptions should be used in place of Null.
The result string is taken from the first resulting tuple, and the first
column (this is why it is called 'exec1') *)

let exec1 s =
  let res=exec s in
    if res#ntuples<1 or res#status<>Tuples_ok
    then None
    else 
      if res#getisnull 0 0
      then None
      else Some (res#getvalue 0 0)

(** Takes a function f : unit -> unit, and ensures
    atomicity. If f raises an exception, transaction is rolled back
    and the exception is thrown again. *)

let transact_m = Mutex.create ()

let transact f =
  (* really stupid implementation, I have better ideas but want
     correctness and want it now *)
  with_lock transact_m 
    (fun () ->
       ignore_exec "begin transaction";
       try 
	 let res = f () in
	   ignore_exec "commit";
	   res
       with exn -> (ignore_exec "rollback";raise exn))	

let createdb_and_open_connection () =
  let name = (Filename.quote (Schema.db_name ())) in
    if 0 = Sys.command ("createdb " ^ name ^ " > /dev/null 2>&1")
    then (* db does not exist *)
      (log ("creating database " ^ name);
       let descr = Unix.open_process_out ("psql -d " ^ name ^ " > /dev/null 2>&1") in
	 output_string descr Schema.schema;
	 ignore (Unix.close_process_out descr)); (* TODO: check for errors here *)
    ignore (Thread.create 
	      (fun () -> 
		 let conn=new connection ~dbname:(Schema.db_name ()) () in
		   while true do
		     sync (receive chan) conn
		   done) ());
    match exec1 "select schema_version()" with
	None -> Some "none"
      | Some version ->
	  if version <> Schema.version
	  then Some version
	  else None
