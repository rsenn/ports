(*
  This file is part of the "RelFS" program.

  RelFS is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation (version 2 of the License).

  RelFS is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with RelFS.  See the file LICENSE.  If you haven't received
  a copy of the GNU General Public License, write to:

  Free Software Foundation, Inc.,
  59 Temple Place, Suite 330, Boston, MA
  02111-1307  USA

  Vincenzo Ciancia

  applejack at users.sf.net
  vincenzo_ml at yahoo.it
  ciancia at di.unipi.it
*)

(** Utility functions mainly related to file handling *)

open Printf
open List
open Unix

let is_write_mode flags = exists (fun x -> x = O_RDWR or x = O_WRONLY) flags

let lpath x = ("." ^ x) (* TODO: substr(x,1,n)???*)
let local fn x = fn (lpath x)

module Opt = struct
  let map f x =
    match x with
	None -> None
      | Some y -> Some (f y)
  let (>>=) f g =
    fun x -> match f x with
	None -> None
      | Some y -> g y
  let rec fold_list_opt f s l =
    match l with
	[] -> s
      | x::xs ->
	  match f s x with
	      None -> s
	    | Some s1 -> fold_list_opt f s1 xs

  let unopt x = match x with None -> raise Not_found | Some y -> y
end

let with_lock m f =
  Mutex.lock m;
  let res =
    try
      f ()
    with err -> 
      Mutex.unlock m;
      raise err 
  in
    Mutex.unlock m;
    res


(* Todo: this used to be "Printf.eprintf", but changed in order to be coherent
   with fuse, which prints debug output on standard output; report this bug to
   Fuse and put eprintf again here *)
let log str =
  let tod =  localtime (time ()) in 
    Printf.printf "%d%02d%02d %02d:%02d:%02d [Thread %d] %s\n%!" 
      (1900+tod.tm_year) (1+tod.tm_mon) tod.tm_mday tod.tm_hour tod.tm_min tod.tm_sec
      (Thread.id (Thread.self ())) str

let log_op opname operation =
  fun arg ->
    log (opname ^ " " ^ arg);
    operation arg

let log_op_2str opname operation =
  fun arg1 arg2 ->
    log (opname ^ " '" ^ arg1 ^ "' '" ^ arg2 ^ "'");
    operation arg1 arg2

let log_op_2int opname operation =
  fun arg1 arg2 ->
    log (Printf.sprintf "%s '%s' '%o'" opname arg1 arg2);
    operation arg1 arg2

(** Escapes a string for being inserted into a like pattern, using _ as the escape character *)
let escape_like =
  let pat = Pcre.regexp "(\\_|\\%)" in
  let sub = Pcre.subst "_$1" in
    fun str ->
      Pcre.replace ~rex:pat ~itempl:sub (Postgresql.escape_string str)

(** Takes a sorted list and the comparison function used to sort the
    list itself, and returns a list of lists, grouping all elements
    that compare to 0. Resulting groups are sorted in reverse order *)
let s_group_by compare lst = 
  let helper groups elem =
    match groups with
	[] -> [[elem]]
      | []::groups -> [elem]::groups (* this cannot happen by construction *)
      | (group_el::group_els)::groups -> 
	  if 0 = compare elem group_el
	  then (elem::group_el::group_els)::groups
	  else [elem]::(group_el::group_els)::groups in
    List.fold_left helper [] lst

let group_by compare lst = s_group_by compare (List.fast_sort compare lst)

let interleave el lst =
  let rec interleave_rec lst =
    match lst with
	[] -> []
      | [a] -> [a]
      | x::xs -> x::el::(interleave_rec xs) in
    interleave_rec lst

let cache timeout fn = (* TODO: better to have a single deleter thread and a channel ? *)
  let tbl = Hashtbl.create 1000 in
  let mtx = Mutex.create () in
  let spawn_deleter arg =
    Thread.create (fun arg ->
		     Thread.delay timeout;
		     with_lock mtx (fun () -> Hashtbl.remove tbl arg)) arg in
    fun arg ->
      with_lock mtx 
	(fun () ->
	   try
	     Hashtbl.find tbl arg
	   with Not_found ->
	     let x = fn arg in
	       Hashtbl.add tbl arg x;
	       spawn_deleter arg;
	       x)

let split_suffix x =
  try
    let idx = String.rindex x '.' in
      if idx = 0 
      then ("",x)
      else (String.sub x 0 idx,String.sub x idx (String.length x - idx))
  with _ -> (x,"")

let db_kind = function
    S_REG -> 'r'
  | S_DIR -> 'd'
  | S_LNK -> 'l'
      
let ml_kind = function
    'r' -> S_REG
  | 'd' -> S_DIR
  | 'l' -> S_LNK

let db_perm = sprintf "%o"  

let db_time t =
  let x = gmtime t in
    Printf.sprintf "%d-%d-%d %d:%d:%d+0" (1900 + x.tm_year) (x.tm_mon+1) x.tm_mday x.tm_hour x.tm_min x.tm_sec

let absolutize_link path=
        let s=(Unix.readlink path) in
                if s.[0] = '/' then s
                else let full_path=String.concat "/" ((Filename.dirname path)::s::[]) in
                        if full_path.[0] = '/' then full_path
                        else String.concat "/" ((Unix.getcwd ()) :: full_path :: [])
