
SET client_encoding = 'UNICODE';
SET check_function_bodies = false;
SET client_min_messages = warning;


COMMENT ON SCHEMA public IS 'Standard public schema';


SET search_path = public, pg_catalog;


CREATE FUNCTION plpgsql_call_handler() RETURNS language_handler
    AS '$libdir/plpgsql', 'plpgsql_call_handler'
    LANGUAGE c;



CREATE TRUSTED PROCEDURAL LANGUAGE plpgsql HANDLER plpgsql_call_handler;



CREATE FUNCTION int_of_bool(boolean) RETURNS integer
    AS 'select case $1 when true then 1 else 0 end'
    LANGUAGE sql;



CREATE FUNCTION lookup(character varying) RETURNS integer
    AS '-- It does not work on non-normalized paths (e.g. those ending in ''/'' or containing ''//'')

DECLARE

path ALIAS FOR $1;
current_obj integer;
current_path obj.name%TYPE;
counter integer:=2;

BEGIN


SELECT INTO current_obj id FROM obj WHERE name=''/'';

SELECT INTO current_path split_part(path,''/'',counter);

WHILE current_path<>'''' LOOP
   SELECT INTO current_obj id FROM membership INNER JOIN obj ON id=child WHERE parent=current_obj AND name=current_path;
   SELECT INTO counter (counter+1);
   SELECT INTO current_path split_part(path,''/'',counter);
END LOOP;

return current_obj;

END; '
    LANGUAGE plpgsql STABLE;



CREATE FUNCTION lookup_nearest(character varying) RETURNS integer
    AS '-- It does not work on non-normalized paths (e.g. those ending in ''/'' or containing ''//'')

DECLARE

path ALIAS FOR $1;
current_obj integer;
prev_obj integer;
current_path obj.name%TYPE;
counter integer:=2;

BEGIN


SELECT INTO current_obj id FROM obj WHERE name=''/'';

SELECT INTO current_path split_part(path,''/'',counter);

WHILE true LOOP
   prev_obj:=current_obj;
   SELECT INTO current_obj id FROM membership INNER JOIN obj ON id=child WHERE parent=current_obj AND name=current_path;
   SELECT INTO counter (counter+1);
   SELECT INTO current_path split_part(path,''/'',counter);
   IF current_path = '''' 
    THEN RETURN prev_obj; 
   END IF;
END LOOP;

END; '
    LANGUAGE plpgsql STABLE;



CREATE FUNCTION pathof(integer) RETURNS character varying
    AS 'DECLARE

current_obj int;
tmp character varying;
res character varying;
root_id int;

BEGIN

res := '''';
current_obj := $1;
SELECT INTO root_id id FROM obj WHERE name=''/'';

WHILE current_obj <> root_id LOOP
   SELECT INTO tmp,current_obj ''/''||name,parent
   FROM membership INNER JOIN obj ON id=child
   WHERE id=current_obj;

   res := tmp || res;
END LOOP;

RETURN res;

END;'
    LANGUAGE plpgsql STABLE;



CREATE FUNCTION schema_version() RETURNS character varying
    AS 'select split_part(cast(''$Revision: 1.21 $'' as character varying),'' '',2)'
    LANGUAGE sql;


SET default_tablespace = '';

SET default_with_oids = true;


CREATE TABLE membership (
    parent integer NOT NULL,
    child integer NOT NULL
);



COMMENT ON TABLE membership IS 'Membership information for files and directories';



CREATE TABLE obj (
    id serial NOT NULL,
    name character varying(4096) NOT NULL,
    kind character(1),
    perm character varying(4),
    uid integer,
    gid integer,
    size bigint,
    atime timestamp with time zone,
    mtime timestamp with time zone,
    ctime timestamp with time zone
);



COMMENT ON TABLE obj IS 'Basic information about objects, such as their id, their name and the way they are stored';



CREATE TABLE obj_mimetype (
    id integer NOT NULL,
    mimetype character varying(1024) NOT NULL
);



COMMENT ON TABLE obj_mimetype IS 'Association between objects and their types';



ALTER TABLE ONLY obj_mimetype
    ADD CONSTRAINT obj_mimetype_pkey PRIMARY KEY (id, mimetype);



ALTER TABLE ONLY membership
    ADD CONSTRAINT pk_membership_child PRIMARY KEY (child);



ALTER TABLE ONLY obj
    ADD CONSTRAINT pk_obj_id PRIMARY KEY (id);



CREATE INDEX fki_membership_parent_obj_id ON membership USING btree (parent);



CREATE INDEX idx_obj_name ON obj USING btree (name);



ALTER TABLE ONLY membership
    ADD CONSTRAINT fk_membership_child_obj_id FOREIGN KEY (child) REFERENCES obj(id) ON UPDATE CASCADE ON DELETE CASCADE;



ALTER TABLE ONLY membership
    ADD CONSTRAINT fk_membership_parent_obj_id FOREIGN KEY (parent) REFERENCES obj(id) ON UPDATE CASCADE ON DELETE RESTRICT;



ALTER TABLE ONLY obj_mimetype
    ADD CONSTRAINT fk_obj_mimetype_obj_obj FOREIGN KEY (id) REFERENCES obj(id) ON UPDATE CASCADE ON DELETE CASCADE;



REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;



INSERT INTO obj (name,kind) VALUES ('/','d');
