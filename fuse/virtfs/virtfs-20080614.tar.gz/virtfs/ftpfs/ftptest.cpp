/*
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Library General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */

#include "ftpcache.hpp"

#include <iostream>

int
main()
{
    ftp::CachedFTPSession sess ("localhost", 21, 1000, false);
    sess.setUserPassword ("anonymous", "nobody@example.org");
    sess.connect ();
    //ftp::FTPSession::FTPFileReader reader (sess, "/README");
    //ftp::FTPSession::DirListConnection reader (sess, "/");
    ftp::FTPSession::DirListReader reader (sess, "/");
    for(;;) {
        ftp::file_info info;
        if (!reader.get_next (info)) break;
        std::cout << info.name << ' ' << info.mode << ' ' << info.nlink << ' ' << info.uid << ' ' << info.gid << ' ' << info.size << std::endl;
    }
#if 0
    const int buf_size = 1024;
    for(;;) {
        char buf[1024];
        //errno = 0;
        int count = reader.read (buf, buf_size);
        if(!count) break;
        std::cout.write (buf, count).flush();
    }
#endif
    sess.disconnect ();
    return 0;
}
