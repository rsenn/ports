/*
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Library General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */

#ifndef FTPFS_HPP_
#define FTPFS_HPP_

#include "ftpconn.hpp"

#include <memory> // for auto_ptr

#include "../common/fuse.hpp"
#include "../common/symlinks.hpp"

/** @ingroup FUSE FTP */
/*@{*/

// This base class ignores the problem with symlinks
class BaseFTPFS: public FUSE::BaseFilesystem
{
    ftp::FTPSession session;

    static int ftp_response_to_errno (int resp) { // TODO     {
        switch (resp) {
                //case 200:
                //  return 0;
                //500 // Syntax error, command unrecognized. | This may include errors such as command line too long.
                //501 Syntax error in parameters or arguments.
                //202 EOPNOTSUPP?
            case 502:
            case 504:
                return EOPNOTSUPP;
                //503 Bad sequence of commands.
                //110 Restart marker reply.
                //212 Directory status.
                //213 File status.
            case 120:
                return EAGAIN;
                //221 Service closing control connection. | Logged out if appropriate.
                //421 Service not available, closing control connection. | This may be a reply to any command if the service knows it must shut down.
                //425 Can't open data connection.
                //426 Connection closed; transfer aborted.
            case 450:
                return EBUSY;
            case 550:
                return ENOENT; // FIXME
                //451 Requested action aborted. Local error in processing.
            case 551:
                return EIO;
            case 452:
            case 552:
                return ENOSPC;
            case 553:
                return EINVAL; // File name not allowed. // TODO: Better errno value?
        }
    }

public:
    int getattr (const char *name, struct stat *st) {
        // FIXME: Can be name == "/"?
        // TODO: Sometimes it's faster to use "individual" listing (for one file).
        // I'm however not sure that it will work with all FTP servers
        std::string dir = name;
        if (dir.size () > 1 && dir[dir.size () - 1] == '/') // possible?
            dir.resize (dir.size () - 1);
        const std::size_t last_slash = dir.rfind ('/');
        dir.resize (last_slash);
        cached_dir_info dirinfo = scan_directory ();
        *st = cached_dir_info[std::string (name.begin () + last_slash + 1, name.end ())]; // FIXME
    }
    int readlink (const char *name, char *buf, size_t size)
    int mknod (const char *name, mode_t mode, dev_t dev)
    int mkdir (const char *name, mode_t mode)
    int unlink (const char *name)
    int rmdir (const char *name)
    int symlink (const char *from, const char *to)
    int rename (const char *from, const char *to)
    int link (const char *from, const char *to)
    int chmod (const char *name, mode_t mode)
    int chown (const char *name, uid_t uid, gid_t gid)
    int truncate (const char *name, off_t off)
    int utime (const char *name, struct utimbuf *time)
    int open (const char *name, struct fuse_file_info *info)
    int read (const char *name, char *buf, size_t size, off_t off, struct fuse_file_info *info)
    int write (const char *name, const char *buf, size_t size, off_t off, struct fuse_file_info *info)
    int statfs (const char *name, struct statvfs *buf)
    int flush (const char *name, struct fuse_file_info *info)
    int release (const char *name, struct fuse_file_info *info)
    int fsync (const char *name, int datasync, struct fuse_file_info *info)
    int setxattr (const char *name, const char *attr, const char *value, size_t size, int flags)
    int getxattr (const char *name, const char *attr, char *value, size_t size)
    int listxattr (const char *name, char *attr, size_t size)
    int removexattr (const char *name, const char *attr)
    int opendir (const char *name, struct fuse_file_info *info)
    int readdir (const char *name, void *buf, fuse_fill_dir_t fill, off_t off, struct fuse_file_info *info)
    int releasedir (const char *name, struct fuse_file_info *info)
    int fsyncdir (const char *name, int datasync, struct fuse_file_info *info)
    void *init ()
    void destroy (void *)
    int access (const char *name, int mode)
    int create (const char *name, mode_t mode, struct fuse_file_info *info)
    int ftruncate (const char *name, off_t off, struct fuse_file_info *info)
    int fgetattr (const char *name, struct stat *st, struct fuse_file_info *info)
};

// This class uses SIZE command to get size of pointed symlinks
class FTPFS: public FUSE::FilesystemDereferencingLinks<BaseFTPFS>
{
    // TODO
};

/*@}*/

#endif // FTPFS_HPP_
