/*
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Library General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */

// TODO: Should have .cpp file

#ifndef FTP_CONN_HPP_
#define FTP_CONN_HPP_

// 250 or 226 reply indicates whether data was closed

/** This class hierarchy may be too complex as is done in accordance with OO principles. */

#include "../common/tcp.hpp"

#include <exception>

#ifdef __GCC__
#  define VFTPLIB_NORETURN_FUNCTION __attribute__ ((noreturn))
#else
#  define VFTPLIB_NORETURN_FUNCTION /* */
#endif

/** FTP library namespace @ingroup FTP */
namespace ftp
{

/** @defgroup FTP FTP Filesystem C++ Library
 *
 * This is the FTP client library used in
 * <a href="http://freesoft.ex-code.com/ftpfs.xml">FTP Filesystem (ftpfs) v3</a>.
 * It can as well be used independently of the FTP filesystem for other FTP
 * clients.
 *
 * This library is on early stage of development and may contain many bugs.
 * It is also not optimized for CPU efficiency yet, so probably is slow.
 *
 * @section urls_sec References
 *
 * <ul>
 * <li><a href="http://freesoft.ex-code.com/ftpfs.xml">FTP Filesystem and FTP C++ Library homepage</a></li>
 * </ul>
 *
 * @todo FTPConfig class which will hold such things as active/passive mode.
 */
/*@{*/

// TODO: (For efficiency) remove superfluos virtual bases
// TODO: what() method of exceptions.

/** Includes support for sending FTP commands and receiving responses */
class BaseFTPConnection
{
private:
    BaseFTPConnection (const BaseFTPConnection &);
public:
    class FTPResponse
    {
        unsigned _resp;
    public:
        FTPResponse (const FTPResponse &r) : _resp (r._resp) { }
        FTPResponse (unsigned resp) : _resp (resp) { }
        unsigned code () const { return _resp; }
        operator unsigned () const { return _resp; }
    };

    class FTPException: public std::exception { };

    class FTPResponseException: virtual public FTPException, public FTPResponse
    {
    public:
        FTPResponseException (const FTPResponse &r) : FTPResponse (r.code ()) { }
        FTPResponseException (unsigned resp) : FTPResponse (resp) { }
    };
    /** Exception thrown on ill-formatted FTP server responses. */
    class FTPBadReply: public FTPException { };
    class FTPConnectionException: public FTPException { };
    class FTPControlConnectionException: public FTPConnectionException { };
    class FTPDataConnectionException: public FTPConnectionException { };
protected:
    TCP::milliseconds_t _timeout;
    TCP::tcp_stream cstream; /**< Change API to be faster: private tcp_streambuf with readline function. */
    bool _active;
    virtual void throw_exception_with_possible_again (const FTPException &e) {
        throw e;
    }
public:
    virtual ~BaseFTPConnection () { }

    void throw_response_if_noteq (unsigned code, FTPResponse resp) {
        if(resp != code)
            throw_exception_with_possible_again (FTPResponseException (resp));
    }

    class DataConnection;

    /** There should be no more than one DataConnectionImpl for an FTPConnection.
      * However it could be fixed simply by remembering last DataConnectionImpl and
      * checking whether it is the same. */
    class DataConnectionImpl
    {
        friend class DataConnection; // hack
    protected:
        BaseFTPConnection &_ftp_conn;
    private:
        loff_t _offset, real_offset; // preserve offset between network disconnects
        TCP::tcp_streambuf dstream;
        std::string _command;
        bool _active, command_was_executed;
        char _transfer_mode, real_transfer_mode;

    protected:
        void throw_exception_with_possible_again (const FTPException &e) {
            _ftp_conn.throw_exception_with_possible_again (e);
        }
        void throw_response_if_noteq (unsigned code, FTPResponse resp) {
            _ftp_conn.throw_response_if_noteq (code, resp);
        }
        FTPResponse execute_command(const std::string &cmd) {
            return _ftp_conn.execute_command(cmd);
        }
        void do_execute_command(const std::string &cmd) {
            _ftp_conn.do_execute_command(cmd);
        }
    public:
        // FIXME: Transfer mode
        DataConnectionImpl (BaseFTPConnection &ftp_conn, const std::string &command, bool active, char transfer_mode = 'I')
            : _ftp_conn (ftp_conn), _offset (0), _command (command), _active (active), _transfer_mode (transfer_mode)
        { }
        DataConnectionImpl (BaseFTPConnection &ftp_conn, const std::string &command, char transfer_mode = 'I')
            : _ftp_conn (ftp_conn), _offset (0), _command (command), _active (ftp_conn._active), _transfer_mode (transfer_mode)
        { }
        DataConnectionImpl (BaseFTPConnection &ftp_conn, bool active, char transfer_mode = 'I')
            : _ftp_conn (ftp_conn), _offset (0), _active (active), _transfer_mode (transfer_mode)
        { }
        DataConnectionImpl (BaseFTPConnection &ftp_conn, char transfer_mode = 'I')
            : _ftp_conn (ftp_conn), _offset (0), _active (ftp_conn._active), _transfer_mode (transfer_mode)
        { }

        BaseFTPConnection &get_ftp_connection () { return _ftp_conn; }
        /** Read warning below.
         * The streambuf does not track stream position. (@todo manual adjusting position.)
         * The streambuf may throw any exceptions!
         */
        std::streambuf &rdbuf() {
            execute_connect (); // hack // FIXME: again/repeat
            return dstream;
        }
        void disconnect () { dstream.disconnect (); }
        void set_command (const std::string &cmd) {
            if (cmd == _command) return;
            _command = cmd;
            command_was_executed = false;
        }
        void set_transfer_mode (char mode) { _transfer_mode = mode; }
        void set_offset (loff_t offset) { _offset = offset; }
        int read (void *buf, int count) {
            execute_connect ();
            const loff_t bytes = dstream.sgetn(reinterpret_cast<char*>(buf), count);
            dstream.pubsync();
            _offset += bytes;
            real_offset += bytes;
            return bytes;
        }
        int write (const void *buf, int count) {
            execute_connect ();
            const loff_t bytes = dstream.sputn(reinterpret_cast<const char*>(buf), count);
            dstream.pubsync();
            _offset += bytes;
            real_offset += bytes;
            return bytes;
        }
    private:
        void execute_connect () {
            if (dstream.is_connected ()) { // FIXME
                restore_offset ();
                return;
            }
            if(_active)
                execute_connect_active();
            else
                execute_connect_passive();
            real_offset = 0; // Always?
            real_transfer_mode = '\0';
        }
        /** MUST be immediately followed by a transfer command */
        void restore_offset () { // normally returns 350, but may return 421
            if(real_transfer_mode != _transfer_mode) {
                execute_command (std::string ("TYPE ") + _transfer_mode);
                real_transfer_mode = _transfer_mode;
            }
            if(real_offset != _offset) {
                // I assume loff_t is 64 bit, that is 20 digits max
                char cmd_buf[5+20+1];
                std::sprintf (cmd_buf, "REST %llu", _offset);
                throw_response_if_noteq (350, execute_command (cmd_buf));
                real_offset = _offset;
            }
        }
        void execute_connect_active() {
            TCP::TCPServer serv (0, _ftp_conn._timeout);

            // An old variant was using control connection IP as fallback
            // if getting IP of the server was failed (may it fail?)
            TCP::IPAddress local_ip;
            TCP::port_t local_port;
            serv.getLocal (local_ip, local_port); // Can this call fail?

            const unsigned long uLocalIP = local_ip;
            char cmd_buf[5+3+1+3+1+3+1+3+1+3+1+3+1]; // TODO: IPv6 support
            std::sprintf (cmd_buf, "PORT %u,%u,%u,%u,%u,%u",
                          unsigned((uLocalIP >> 0 ) & 0xff),
                          unsigned((uLocalIP >> 8 ) & 0xff),
                          unsigned((uLocalIP >> 16) & 0xff),
                          unsigned((uLocalIP >> 24) & 0xff),
                          unsigned(local_port >> 8),
                          unsigned(local_port & 0xff));

            throw_response_if_noteq (200, execute_command(cmd_buf));

            restore_offset ();
            throw_response_if_noteq (150, execute_command (_command));

            TCP::IPAddress remote_ip;
            int remote_port;
            if (!serv.waitConnect (remote_ip, remote_port))
                throw_exception_with_possible_again (FTPDataConnectionException ()); // TODO: errno
            dstream.connect(serv);
        }
        void execute_connect_passive() {
            do_execute_command ("PASV");

            std::string buf;
            std::getline (_ftp_conn.cstream, buf);

            // This is only partial checking
            if (!::isdigit (buf[0]) || ::atoi (buf.c_str ()) != 227)
                throw FTPBadReply ();

            unsigned long remote_ip;
            TCP::port_t remote_port;
            if (!getIP (buf.c_str () + buf.find ('('), remote_ip, remote_port))
                throw FTPBadReply (/*"Could not extract ip/port information"*/); // TODO: error msg

            // First execute, then connect and then wait for 150 reply
            restore_offset ();
            do_execute_command (_command);
            dstream.connect (TCP::IPAddress (remote_ip), remote_port);
            //throw_response_if_noteq (150, get_response());
            FTPResponse resp = _ftp_conn.get_response ();
            if(resp != 150) {
                dstream.disconnect (); // TODO: necessary here?
                throw_exception_with_possible_again (FTPResponseException (resp));
            }
        }
        static bool getIP (const char *buf, unsigned long &ip, TCP::port_t &port) {
            int res;
            unsigned char i0, i1, i2, i3, p0, p1;

            if((res = sscanf (buf, " (%hhu,%hhu,%hhu,%hhu,%hhu,%hhu)", &i0, &i1, &i2, &i3, &p0, &p1)) != 6) {
                //WARN("bad format, res=" << res);
                return false;
            }

            //TRACE("buf: " << buf);
            //TRACE("(i0,i1,i2,i3,p0,p1)=("<<(int)i0<<","<<(int)i1<<","<<(int)i2<<","<<(int)i3<<","<<(int)p0<<","<<(int)p1<<")");

            ip = (((unsigned)i0) << 24) + (((unsigned)i1) << 16) + (((unsigned)i2) << 8) + (unsigned)i3;
            port = (((unsigned)p0) << 8) + (unsigned)p1;

            //TRACE("IP: " << *ip << "(" << inet_ntoa(*(struct in_addr*)ip) << ")");
            //TRACE("port: " << *port);

            return true;
        }
    };

private:
    DataConnectionImpl m_data_conn;
public:
    /** This class either creates a data connection or gives us one of the used data connections.
      * Note that this data connection may be reused by other routines.
      */
    class DataConnection
    {
    protected:
        DataConnectionImpl &impl;

        void throw_exception_with_possible_again (const FTPException &e) // hack {
            return impl.throw_exception_with_possible_again (e);
        }
    public:
        // FIXME: Transfer mode
        DataConnection (BaseFTPConnection &ftp_conn, const std::string &command, char transfer_mode = 'I')
            : impl (ftp_conn.m_data_conn)
        {
            impl.set_command (command);
            set_transfer_mode (transfer_mode);
        }
        DataConnection (BaseFTPConnection &ftp_conn, char transfer_mode = 'I')
            : impl (ftp_conn.m_data_conn)
        {
            set_transfer_mode (transfer_mode);
        }

        BaseFTPConnection &get_ftp_connection () { return impl.get_ftp_connection (); }
        /** The streambuf may throw any exceptions! */
        std::streambuf &rdbuf () { return impl.rdbuf (); }
        //void disconnect (); // FIXME: Should be called at least in destructor
        void set_command (const std::string &cmd) { impl.set_command (cmd); }
        void set_transfer_mode (char mode) { impl.set_transfer_mode (mode); }
        void set_offset (loff_t offset) { impl.set_offset (offset); }
        int read (void *buf, int count) { return impl.read (buf, count); }
        int write (const void *buf, int count) { return impl.write (buf, count); }
    };
    class DataConnectionHolder
    {
        BaseFTPConnection &_ftp_conn;
    public:
        DataConnectionHolder (BaseFTPConnection &ftp_conn, const std::string &command, char transfer_mode = 'I')
            : _ftp_conn(ftp_conn)
        {
            DataConnectionImpl &conn = ftp_conn.m_data_conn;
            conn.set_command (command);
            conn.set_transfer_mode (transfer_mode);
        }
        DataConnectionHolder (BaseFTPConnection &ftp_conn, char transfer_mode = 'I')
            : _ftp_conn(ftp_conn)
        {
            DataConnectionImpl &conn = ftp_conn.m_data_conn;
            conn.set_transfer_mode (transfer_mode);
        }
        DataConnectionImpl *get () { return &_ftp_conn.m_data_conn; }
        operator DataConnectionImpl* () { return get (); }
        DataConnectionImpl *operator -> () { return get (); }
    };

    BaseFTPConnection (const std::string &host, TCP::port_t port, TCP::milliseconds_t timeout, bool active = false)
        : _timeout (timeout), cstream (host, port, timeout), _active (active),
          m_data_conn (*this)
    {
        // FIXME: set timeout for dstream
        // I was anyway too lazy to handle errors manually
        using std::ios_base;
        cstream.exceptions (ios_base::failbit | ios_base::badbit | ios_base::eofbit); // TODO: The same for dstream
    }

    virtual void initial_conversation () = 0;

    void do_connect () { cstream.connect (); }

    void connect () {
        if (cstream.is_connected ()) return;
        do_connect ();
        initial_conversation ();
    }

    void disconnect () {
        cstream.disconnect ();
        //dstream.disconnect (); // FIXME
    }

    FTPResponse get_response() {
        std::string line;
        std::getline (cstream, line);
        if(line.empty () || !std::isdigit (line[0]))
            throw FTPBadReply();
        const char *str = line.c_str();
        // TODO: I stupidly follow the algorithm borrowed from LUFS's ftpfs... check
        char *end;
        FTPResponse resp = ::strtoul (str, &end, 10);
        if(end != str + 3) throw FTPBadReply();
        if(*end == '-') { // multiline
            const FTPResponse multiline = resp;
            do {
                std::getline (cstream, line);
                if (line[3] != ' ') continue;
                str = line.c_str ();
                resp = ::strtoul (str, &end, 10);
                if (end != str + 3) continue;
            } while (resp != multiline);
        }
        return resp;
    }

    void do_execute_command(const std::string &cmd) {
        cstream << cmd << "\r\n"/* Is '\r' necessary? */ << std::flush;
    }

    FTPResponse execute_command(const std::string &cmd) {
        do_execute_command(cmd);
        return get_response();
    }

};

/** catches and rethrows ios_base::failure */
class BaseFTPConnectionWithFTPConnectionExceptions: public BaseFTPConnection
{
    typedef BaseFTPConnection base_class;

public:
    /** Catches and rethrows streambuf dstream exceptions. */
    class DataConnection: public base_class::DataConnection
    {
    public:
        DataConnection (BaseFTPConnectionWithFTPConnectionExceptions &ftp_conn, const std::string &command, bool active)
            : base_class::DataConnection (ftp_conn, command, active)
        { }
        DataConnection (BaseFTPConnectionWithFTPConnectionExceptions &ftp_conn, const std::string &command)
            : base_class::DataConnection (ftp_conn, command)
        { }
#if 0
        void disconnect () { // Would be better implemented in the base class
            try {
                base_class::DataConnection::disconnect ();
            } catch (const std::ios_base::failure &) {
                throw_exception_with_possible_again (FTPDataConnectionException ());
            }
        }
#endif
        int read (void *buf, int count) {
            int res;
            try {
                res = base_class::DataConnection::read (buf, count);
            } catch (...) {
                throw_exception_with_possible_again (FTPDataConnectionException ());
            }
            return res; // needed here for no GCC warn.
        }
        int write(const void *buf, int count) {
            int res;
            try {
                res = base_class::DataConnection::write (buf, count);
            } catch (...) {
                throw_exception_with_possible_again (FTPDataConnectionException ());
            }
            return res; // needed here for no GCC warn.
        }
    };

    BaseFTPConnectionWithFTPConnectionExceptions (const std::string &host,
                                                  TCP::port_t port,
                                                  TCP::milliseconds_t timeout,
                                                  bool active = false)
        : base_class (host, port, timeout, active)
    { }
    void exception_failure_to_ftpexception () VFTPLIB_NORETURN_FUNCTION {
        // This probably could be optimized having special stream class impl. throwing special exceptions.
        if (cstream.bad ()) { // dstream exceptions are handled separately
            cstream.clear ();
            throw_exception_with_possible_again (FTPControlConnectionException ());
        } else
            throw;
    }
    FTPResponse execute_command (const std::string &cmd) { // Slow because duplicates exception handling of get_response()
        FTPResponse resp (0);
        try {
            resp = base_class::execute_command (cmd);
        } catch (const std::ios_base::failure &) {
            exception_failure_to_ftpexception ();
        }
        return resp; // needed here to eliminate GCC warn.
    }
    // do_execute_command() and get_response() are not try-catch wrapped!
    // (TODO: Wrap them in debug mode)
};

/** Has FTPAgain exception. */
class BaseFTPConnectionWithAgain: public BaseFTPConnectionWithFTPConnectionExceptions
{
    typedef BaseFTPConnectionWithFTPConnectionExceptions base_class;
public:
    class FTPAgain: virtual public FTPException { };
    class FTPAgainResponse: virtual public FTPAgain,
                            virtual public FTPResponse
    {
    public:
        FTPAgainResponse (unsigned resp) : FTPResponse (resp) { }
        FTPAgainResponse (FTPResponse &r) : FTPResponse (r) { }
    };
    class FTPConnectionAgain: virtual public FTPAgain,
                              virtual public FTPConnectionException
    { };

    BaseFTPConnectionWithAgain (const std::string &host,
                                TCP::port_t port,
                                TCP::milliseconds_t timeout,
                                bool active = false)
        : base_class (host, port, timeout, active)
    { }

private:
    void exception_response_to_ftpagain (const FTPResponse &e) {
        switch (e.code ())
        {
            case 120: // service ready in nnn minutes
            case 421:
            case 425:
            case 426:
            case 450:
                throw FTPAgainResponse (e);
            default:
                throw e;
        }
    }
    void exception_failure_to_again (const FTPConnectionException &e) {
        throw FTPConnectionAgain ();
    }
protected:
    void throw_exception_with_possible_again (FTPException &e) { // virtual override
        try { // Seems very slow...
            throw e;
        } catch (const FTPResponse &e) {
            exception_response_to_ftpagain (e);
        } catch (const FTPConnectionException &e) {
            exception_failure_to_again (e);
        } catch (...) {
            throw;
        }
    }
public:
    class DataConnection: public base_class::DataConnection
    {
    public:
        DataConnection (BaseFTPConnectionWithFTPConnectionExceptions &ftp_conn, const std::string &command, bool active)
            : base_class::DataConnection (ftp_conn, command, active)
        { }
        DataConnection (BaseFTPConnectionWithFTPConnectionExceptions &ftp_conn, const std::string &command)
            : base_class::DataConnection (ftp_conn, command)
        { }
        //void disconnect () // again for disconnect() looks like stupid
        int read (void *buf, int count) {
            int res;
            try {
                res = base_class::DataConnection::read (buf, count);
            } catch (const FTPConnectionException &e) {
                throw_exception_with_possible_again (FTPDataConnectionException ());
            }
            return res; // needed here for no GCC warn.
        }
        int write(const void *buf, int count) {
            int res;
            try {
                res = base_class::DataConnection::write (buf, count);
            } catch (const FTPConnectionException &e) {
                throw_exception_with_possible_again (FTPDataConnectionException ());
            }
            return res; // needed here for no GCC warn.
        }
    };
};

/** currently doesn't differ from its base */
class FTPConnectionWithAgain: public BaseFTPConnectionWithAgain
{
    typedef BaseFTPConnectionWithAgain base_class;
public:
    FTPConnectionWithAgain (const std::string &host,
                            TCP::port_t port,
                            TCP::milliseconds_t timeout,
                            bool active = false)
        : base_class (host, port, timeout, active)
    { }
};

/** Automatically repeats action if server/network problems */
class BaseFTPConnectionWithRepeat: public FTPConnectionWithAgain
{
    typedef FTPConnectionWithAgain base_class;
    static const int FTP_MAXTRIES = 7;
    class MaxTriesExceeded: public FTPException { };

    template<class Functor>
    typename Functor::result_type execute_repeated (Functor f) { // Isn't passing f by value slow?
        for (int attempt=0; attempt < FTP_MAXTRIES; ++attempt) {
            connect (); // right place for this?
            try {
                return f();
                //return base_class::execute_command(cmd);
                // 221 421 425 426 450
                //if (resp != 421) break; // service unavailable
            }
            catch (const FTPAgain &) { }
        }
        throw MaxTriesExceeded();
    }
    template<class Functor>
    typename Functor::result_type execute_repeated_noreturn (Functor &f) {
        for (int attempt=0; attempt < FTP_MAXTRIES; ++attempt) {
            connect (); // right place for this?
            try {
                f();
                return;
            }
            catch (const FTPAgain &) { }
        }
        throw MaxTriesExceeded();
    }

    struct CommandExecutor
    {
        typedef FTPResponse result_type;
        base_class &_ftp;
        const std::string &_cmd;
        CommandExecutor (BaseFTPConnectionWithRepeat &ftp, const std::string &cmd)
            : _ftp (ftp), _cmd (cmd)
        { }
        FTPResponse operator () () { return _ftp.execute_command (_cmd); }
    };
public:
    BaseFTPConnectionWithRepeat (const std::string &host,
                                 TCP::port_t port,
                                 TCP::milliseconds_t timeout,
                                 bool active = false)
        : base_class (host, port, timeout, active)
    { }

    FTPResponse execute_command (const std::string &cmd) {
        return execute_repeated (CommandExecutor (*this, cmd));
    }

    class DataConnection: public base_class::DataConnection
    {
    private:
        struct BaseExecutor
        {
            typedef int result_type;
            BaseExecutor (base_class::DataConnection &conn, void *buf, int count)
                : _conn (conn), _buf (buf), _count (count)
            { }
            base_class::DataConnection &_conn;
            void *_buf;
            int _count;
        };
        struct ReadExecutor: BaseExecutor
        {
            ReadExecutor (base_class::DataConnection &conn, void *buf, int count)
                : BaseExecutor(conn, buf, count)
            { }
            int operator () () { return _conn.read (_buf, _count); }
        };
        struct WriteExecutor: BaseExecutor
        {
            WriteExecutor (base_class::DataConnection &conn, const void *buf, int count)
                : BaseExecutor(conn, const_cast<void*>(buf), count)
            { }
            int operator () () { return _conn.write (_buf, _count); }
        };
    public:
        DataConnection (BaseFTPConnectionWithRepeat &_ftp_conn, const std::string &command, bool active)
            : base_class::DataConnection (_ftp_conn, command, active)
        { }
        DataConnection (BaseFTPConnectionWithRepeat &_ftp_conn, const std::string &command)
            : base_class::DataConnection (_ftp_conn, command)
        { }
        //void disconnect () // probably doesn't make sense
        int read (void *buf, int count) {
            return static_cast<BaseFTPConnectionWithRepeat&> (get_ftp_connection ()).
                   execute_repeated (ReadExecutor (*this, buf, count));
        }
        int write(const void *buf, int count) {
            return static_cast<BaseFTPConnectionWithRepeat&> (get_ftp_connection ()).
                   execute_repeated (WriteExecutor (*this, buf, count));
        }
    };
};

/** doesn't differ from its base */
class FTPConnectionWithRepeat: public BaseFTPConnectionWithRepeat
{
    typedef BaseFTPConnectionWithRepeat base_class;
public:
    FTPConnectionWithRepeat (const std::string &host,
                             TCP::port_t port,
                             TCP::milliseconds_t timeout,
                             bool active = false)
        : base_class (host, port, timeout, active)
    { }
};

/*@}*/

} // namespace ftp

#endif // FTP_CONN_HPP_
