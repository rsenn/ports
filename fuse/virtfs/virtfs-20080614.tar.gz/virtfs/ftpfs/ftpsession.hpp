/*
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Library General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */

// TODO: Should have .cpp file

#ifndef FTP_SESSION_HPP_
#define FTP_SESSION_HPP_

#include "ftpconn.hpp"

#include <memory> // for auto_ptr

#include "ftpsystem.hpp"

namespace ftp
{

/** @addtogroup FTP */
/*@{*/

/** @todo bad struct name */
//struct file_info: public struct stat { };
struct inode_info
{
    /** This method may be removed in a future version. */
    void clear () {
        uid = gid = link_dest = "";
        type = '-';
        size = mtime = 0;
        nlink = 1;
        mode = 0777;
    }

    unsigned nlink;
    /** '-' - file, 'd' - dir, 'l' - symlink, 'p' - FIFO, 's' - socket, 'c' - char device, 'b' - block device */
    char type;
    unsigned short mode;
    loff_t size; /**< for symlinks it is link size, not file size.
                      Use FTPSession::execute_size(). */
    time_t mtime;
    std::string uid, gid;
    std::string link_dest;
    //dev_t rdev;
};

/** @todo bad struct name */
struct file_info: inode_info
{
    /** This method may be removed in a future version. */
    void clear () {
        inode_info::clear ();
        name.clear ();
    }
    std::string name;
};

//  namespace Impl
//  {
//    class Impl::FTPSystemDependencies;
//  }

/** This class implements particular FTP commands.
 * Ideally this class should be template to support either
 * primitive FTPConnection or FTPConnectionWithRepeat.
 */
class FTPSession: public FTPConnectionWithRepeat
{
    typedef FTPConnectionWithRepeat base_class;
    //std::string system;
    std::string user, password;
    std::auto_ptr<ftp::Impl::FTPSystemDependencies> system_deps;
public:
    FTPSession (const std::string &host, TCP::port_t port, TCP::milliseconds_t timeout, bool active = false)
        : base_class (host, port, timeout, active)
    { }
    void setUserPassword (const std::string &user, const std::string &password) { // effective after reconnect
        this->user     = user;
        this->password = password;
    }
    FTPResponse execute_chdir (const std::string &name) {
        return execute_command ("CWD " + name);
    }
    FTPResponse execute_pwd (std::string &name) {
        /** @bug not implemented */
        return 0;
    }
    FTPResponse execute_mkdir (const std::string &name) {
        return execute_command ("MKD " + name);
    }
    FTPResponse execute_rmdir (const std::string &name) {
        return execute_command ("RMD " + name);
    }
    FTPResponse execute_unlink (const std::string &name) {
        return execute_command ("DELE " + name);
    }
    FTPResponse execute_rename (const std::string &oldname, const std::string &newname) {
        const FTPResponse resp = execute_command ("RNFR " + oldname);
        if(resp != 350) return resp;
        return execute_command ("RNTO " + newname);
    }
    FTPResponse execute_chmod (const std::string &name, mode_t mode) {
        char buf[4];
        ::sprintf(buf, "%o", unsigned (mode & 0777));
        return execute_command (std::string ("SITE CHMOD ") + buf + ' ' + name);
    }
    /** If response is not 213, the value of size becomes unspecified. */
    FTPResponse execute_size (const std::string &name, unsigned long long &size);

    class FTPFileReader: public DataConnection
    {
    public:
        FTPFileReader (FTPSession &ftp_conn, const std::string &name)
            : DataConnection (ftp_conn, "RETR " + name)
        { }
    };

    class FTPFileWriter: public DataConnection
    {
    public:
        FTPFileWriter (FTPSession &ftp_conn, const std::string &name)
            : DataConnection (ftp_conn, "STOR " + name) // FIXME: What about APPE
        { }
    };
    
    /** Base class for DirListReader. */
    class DirListConnection: public DataConnection
    {
        std::istream stream;
    public:
        DirListConnection (FTPSession &ftp_conn, const std::string &name = "", const std::string &command = "LIST -al")
            : DataConnection (ftp_conn, name.empty () ? command : command + " " + name, 'A'),
              stream (&rdbuf())
        { }
        std::istream &get_stream() { return stream; }
    };

    /** @todo Shouldn't be private inheritance for more similarity with cached version of this class? */
    class DirListReader: public DirListConnection
    {
        bool errors;
    public:
        /** Current directory */
        DirListReader (FTPSession &ftp_conn)
            : DirListConnection (ftp_conn), errors (false)
        { }
        DirListReader (FTPSession &ftp_conn, const std::string &name)
            : DirListConnection (ftp_conn, name), errors (false)
        { }
        bool get_next (file_info &info);
        bool were_errors () { return errors; }
    };

protected:
    void auth ();
    void initial_conversation (); // virtual override
};

/** @todo FTPSession child which remembers current dir. */
class FTPSessionWithCwd: public FTPSession
{
public:
    FTPSessionWithCwd (const std::string &host, TCP::port_t port, TCP::milliseconds_t timeout, bool active = false)
        : FTPSession (host, port, timeout, active)
    { }
};

/*@}*/

} // namespace ftp

#endif // FTP_CONN_HPP_
