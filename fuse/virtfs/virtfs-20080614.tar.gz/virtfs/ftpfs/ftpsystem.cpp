/*
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Library General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */

#include "ftpsystem.hpp"

#include "ftpsession.hpp"

namespace ftp
{

namespace Impl
{

bool FTPSystemUnix::parse_dirlist_line (const std::string &line,
                                        file_info &info,
                                        const std::string &_user, const std::string &_password)
{
    unsigned long nlink, size;
    char user[32], group[32], month[5], day[5], year[6];
    char file[1024], link[1024]; // FIXME: or 1025?

    *file = *link = user[0] = group[0] = month[0] = day[0] = year[0] = 0;

    const int scanf_num =
        std::sscanf(line.c_str (), "%*11s %lu %32s %32s %lu %3s %2s %5s %1024s -> %1024s",
                    &nlink, user, group, &size, month, day, year, file, link);
    if(scanf_num < 8) return false;

    const std::string s_date = std::string (year) + ',' + std::string (month) + ',' + std::string (day);
    const time_t tt = ::time(NULL);
    struct tm tm;
    ::gmtime_r(&tt, &tm);
    tm.tm_sec = tm.tm_min = tm.tm_hour = 0;
    ::strptime(s_date.c_str(),
               strchr(year, ':') ? "%H:%M,%b,%d" : "%Y,%b,%d",
               &tm);

    // TODO
    info.uid = user  == "-" ? "" : user ;
    info.gid = group == "-" ? "" : group;

    info.name = file;
    info.nlink = nlink;
    info.size = size;
    info.mtime = mktime(&tm);
    info.type = std::tolower(line[0]);
    if (*link) info.link_dest = link;

    // Should scan mode in sscanf instead...
    if(tolower(line[1]) != '-')
        info.mode |= S_IRUSR;
    if(tolower(line[2]) != '-')
        info.mode |= S_IWUSR;
    if(tolower(line[3]) != '-')
        info.mode |= S_IXUSR;
    if(tolower(line[4]) != '-')
        info.mode |= S_IRGRP;
    if(tolower(line[5]) != '-')
        info.mode |= S_IWGRP;
    if(tolower(line[6]) != '-')
        info.mode |= S_IXGRP;
    if(tolower(line[7]) != '-')
        info.mode |= S_IROTH;
    if(tolower(line[8]) != '-')
        info.mode |= S_IWOTH;
    if(tolower(line[9]) != '-')
        info.mode |= S_IXOTH;

    return true;
}

bool FTPSystemWindows::parse_dirlist_line (const std::string &line,
                                           file_info &info,
                                           const std::string &user,
                                           const std::string &password)
{
    return false; // TODO
#if 0
    unsigned long size = 0;
    int res;
    struct tm tm;
    time_t tt;
    char sDate[20], sTime[20], datetime[40];

    *file = *link = sDate[0] = sTime[0] = datetime[0] = 0;

    if(tolower(buf[25]) == 'd')
        res = sscanf(buf, "%8s %7s %*5s %1024s", sDate, sTime, file);
    else
        res = sscanf(buf, "%8s %7s %lu %1024s", sDate, sTime, &size, file);

    if(res < 2) {
        TRACE("could only match "<<res<<" attributes");
        return -1;
    }

    sprintf(datetime, "%s %s", sDate, sTime);

    tt = time(NULL);
    gmtime_r(&tt, &tm);
    tm.tm_sec = 0;

    strptime(datetime, "%m-%e-%y  %I:%M%p", &tm);

    memset(fattr, 0, sizeof(struct lufs_fattr));

    fattr->f_uid = 1;
    fattr->f_gid = 1;

    fattr->f_nlink = 0;
    fattr->f_size = size;
    fattr->f_ctime = fattr->f_mtime = fattr->f_atime = mktime(&tm);

    if(tolower(buf[25]) == 'd')
        fattr->f_mode = S_IFDIR;
    else
        fattr->f_mode = S_IFREG;

    fattr->f_mode |= S_IRUSR | S_IWUSR | S_IXUSR | S_IRGRP | S_IWGRP | S_IXGRP | S_IROTH | S_IWOTH | S_IXOTH;

    TRACE("file: " << file<<", link: " << link);
    return 0;
#endif // 0
}

bool FTPSystemNetware::parse_dirlist_line (const std::string &line,
                                           file_info &info,
                                           const std::string &user,
                                           const std::string &password)
{
    return false; // TODO
#if 0
    unsigned long nlink, size;
    int res, own = 0;
    struct tm tm;
    time_t tt;
    char user[32], month[5], day[5], year[6], date[20];
    char *c, *cc;

    *file = *link = user[0] = month[0] = day[0] = year[0] = 0;

    nlink = 1;
    if((res = sscanf(buf, "%*2s %*12s %32s %lu %3s %2s %5s %1024s", user, &size, month, day, year, file)) < 6) {
        WARN("could only match "<<res<<" attributes!");

        return -1;
    }

    sprintf(date,"%s,%s,%s", year, month, day);
    tt = time(NULL);
    memcpy(&tm, gmtime(&tt), sizeof(struct tm));
    tm.tm_sec = tm.tm_min = tm.tm_hour = 0;
    if(strchr(year, ':'))
        strptime(date, "%H:%M,%b,%d", &tm);
    else
        strptime(date, "%Y,%b,%d", &tm);

    if(!strcmp(cred->user, user))
        own = 1;

    memset(fattr, 0, sizeof(struct lufs_fattr));
    fattr->f_nlink = nlink;
    fattr->f_size = size;
    fattr->f_ctime = fattr->f_mtime = fattr->f_atime = mktime(&tm);

    if(tolower(buf[0]) == 'd')
        fattr->f_mode = S_IFDIR;
    else
        fattr->f_mode = S_IFREG;

    fattr->f_mode |= S_IRUSR | S_IRGRP | S_IROTH | S_IWUSR | S_IWGRP | S_IWOTH;
    if (fattr->f_mode & S_IFDIR)
        fattr->f_mode |= S_IXUSR | S_IXGRP | S_IXOTH;

    for(c = buf; *c; c++) {
        if((*c == 0x0a) || (*c == 0x0d)) {
            *c = 0;
            break;
        }
    }

    if((c = nth_word(buf, 8))) {
        TRACE("left: " << c);
        cc=strstr(c, "->");
        if(cc != NULL) {
            *(cc-1) = 0;
            strcpy(file, c);
            strcpy(link, (cc + 3));
        } else {
            strcpy(file, c);
        }
        TRACE("file: " << file<<", link: " << link);
        return 0;
    } else
        return -1;
#endif // 0
}

} // namespace Impl

} // namespace ftp
