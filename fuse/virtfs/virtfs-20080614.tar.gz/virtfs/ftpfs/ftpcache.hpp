/*
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Library General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */

#ifndef FTP_CACHE_HPP
#define FTP_CACHE_HPP

#include "ftpsession.hpp"
#include "../common/dircache.hpp"

namespace ftp
{

//using namespace cache;

/** @ingroup FTP DirectoryCache */
/*@{*/

class FTPFileCacheEntry: public cache::BaseFileCacheEntry
{
public:
    /** @todo default value for end_time */
    FTPFileCacheEntry (DirectoryCacheEntry &dir, const std::string &name, time_type end_time)
        : BaseFileCacheEntry (dir, name, end_time)
    { }
    file_info info;
protected: // virtual overrides
    //BaseCache::iterator do_join (BaseCache::iterator newentry, BaseCache::iterator oldentry);
};

class FTPDirectoryCacheEntry: public cache::BaseDirectoryCacheEntry
{
public:
    /** @todo default value of end_time. */
    FTPDirectoryCacheEntry (BaseCacheMap<std::string> &cache_map, const std::string &key, time_type end_time)
        : BaseDirectoryCacheEntry (cache_map, key, end_time)
    { }
};

class CachedFTPSession: public FTPSessionWithCwd
{
    typedef FTPSessionWithCwd base_class;
    BaseCacheMap<std::string> &dir_cache;
public:
    CachedFTPSession (const std::string &host, TCP::port_t port, TCP::milliseconds_t timeout, bool active = false)
        : FTPSessionWithCwd(host, port, timeout, active)
          //, dir_cache (base_cache) // FIXME
    { }
    class DirListReader: public base_class::DirListReader
    {
        DirectoryCacheEntry *dir_cache_entry;
        char DirListReader_place[sizeof(base_class::DirListReader)];
        base_class::DirListReader::const_iterator iter;
        base_class::DirListReader &get_real_reader () {
            assert (!use_cached);
            return *reinterpret_cast<base_class::DirListReader*> (DirListReader_place);
        }
        bool use_cached;
    public:
        /** Current directory */
        DirListReader (FTPSession &ftp_conn); // TODO
        DirListReader (FTPSession &ftp_conn, const std::string &name) {
            dir_cache_entry = dir_cache.get_entry (name); // FIXME: abs./rel. path?
            use_cached = dir_cache_entry && dir_cache_entry.?? ();
            if(use_cached)
                iter = dir_cache_entry->begin ();
            else {
                new (DirListReader_place) DirListReader (ftp_conn, name);
                dir_cache_entry = ftp_conn.dir_cache.get_entry (name);
                if (dir_cache_entry)
                    ??
                else
                    dir_cache_entry = ftp_conn.dir_cache.add_entry (new );
                // FIXME: allocate or reset old dir cache entry
            }
        }
        bool get_next (file_info &info) {
            if (use_cached) {
                if (iter == dir_cache_entry->end ()) return false;
                info = iter->info;
                ++iter;
            } else {
                // TODO: "complete"
                if (!get_real_reader().get_next (info))
                    return false;
                dir_cache_entry->add_entry (new FTPFileCacheEntry (*dir_cache_entry, info.name),
                                            false);
            }
            return true;
        }
        bool were_errors () { return false; } /**< @todo */
    };
};

/*@}*/

} // namespace ftp

#endif // FTP_CACHE_HPP
