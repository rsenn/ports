/*
*  This program is free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
*
*  This program is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU Library General Public License for more details.
*
*  You should have received a copy of the GNU General Public License
*  along with this program; if not, write to the Free Software
*  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
*/

#ifndef FTPSYSTEM_HPP_
#define FTPSYSTEM_HPP_

#include <string>

//#include "ftpsession.hpp"

namespace ftp
{

/** @addtogroup FTP */
/*@{*/

class file_info;

namespace Impl
{

/** @internal */
class FTPSystemDependencies
{
public:
    virtual ~FTPSystemDependencies() { }
    virtual bool parse_dirlist_line (const std::string &line,
                                     file_info &info,
                                     const std::string &user,
                                     const std::string &password) = 0;
};

/** @internal */
class FTPSystemUnix: public FTPSystemDependencies
{
public:
    bool parse_dirlist_line (const std::string &line,
                             file_info &info,
                             const std::string &user,
                             const std::string &password);
};

/** @internal */
class FTPSystemWindows: public FTPSystemDependencies
{
public:
    bool parse_dirlist_line (const std::string &line,
                             file_info &info,
                             const std::string &user,
                             const std::string &password);
};

/** @internal */
class FTPSystemNetware: public FTPSystemDependencies
{
public:
    bool parse_dirlist_line (const std::string &line,
                             file_info &info,
                             const std::string &user,
                             const std::string &password);
};

} // namespace Impl

/*@}*/

} // namespace ftp

#endif // FTPSYSTEM_HPP_
