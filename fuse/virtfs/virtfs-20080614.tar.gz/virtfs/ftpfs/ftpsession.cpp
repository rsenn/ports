/*
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Library General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */

#include "ftpsession.hpp"

#include <string>

namespace ftp
{

// FIXME: again/repeat
bool FTPSession::DirListReader::get_next (file_info &info)
{
    bool res;
    do {
        // FIXME: Skip "total N" line
        std::string line;
        //execute_connect (); // hack
        std::getline (get_stream (), line);
        if (get_stream ().eof ()) return false;
        info.clear ();
        FTPSession &ftp = static_cast<FTPSession &> (get_ftp_connection ());
        res = ftp.system_deps->parse_dirlist_line (line, info, ftp.user, ftp.password);
        if (!res) errors = true;
    } while(!res);
    return true;
}

void FTPSession::auth ()
{
    if(!user.empty ()) {
        const FTPResponse resp = execute_command ("USER "+user);
        switch (resp)
        {
            case 331:
                if (!password.empty ()) // TODO: Does empty password has meaning?
                    throw_response_if_noteq (230, execute_command ("PASS "+password));
                break;
            case 230:
                break;
            default:
                throw FTPResponseException (resp);
        }
    }
}

void FTPSession::initial_conversation ()
{
    // TODO: In the ftpfs from LUFS it attempts to read /etc/passwd Why?
    throw_response_if_noteq (220, get_response ());
    auth ();
    // TODO: Check system only at first login?
    do_execute_command ("SYST");
    std::string line;
    std::getline (cstream, line);
    unsigned res;
    char sys[33];
    if (::sscanf (line.c_str (), "%u %32s", &res, sys) != 2 || res != 215)
        throw FTPBadReply (); // TODO: error msg
    //system = sys;
    // Shouldn't we do no-case comparison?
    if(!std::strcmp(sys, "NETWARE"))
        system_deps.reset (new Impl::FTPSystemNetware);
    else if(!std::strncmp(sys, "Windows", 7)) /*"Windows_NT"*/
        system_deps.reset (new Impl::FTPSystemWindows);
    else
        system_deps.reset (new Impl::FTPSystemUnix);
}

FTPSession::FTPResponse FTPSession::execute_size (const std::string &name, unsigned long long &size)
{
    do_execute_command ("SIZE " + name);
    std::string line;
    std::getline (cstream, line);
    unsigned status;
    std::sscanf (line.c_str (), "%u %llu", &status, &size);
    return status;
}

} // namespace ftp
