/*
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Library General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */

#ifndef BASECACHE_HPP_
#define BASECACHE_HPP_

#include <list>
#include <map>
#include <utility> // for std::rel_ops
#ifndef NDEBUG
#  include <cassert>
#endif

/** Advanced caching library namespace @ingroup AbstractCache DirectoryCache */
namespace cache
{

using namespace std::rel_ops;

/**
 * @defgroup AbstractCache Advanced In-Memory Caching C++ Template Library
 *
 * This implements advanced abstract caching classes with timeout.
 *
 * These classes can be used for instance for caching file and directory
 * information (see @ref DirectoryCache).
 *
 * Using this library you can create several caches (derived from BaseCache)
 * each cache having a fixed timeout. Cache entries are put into these caches
 * and can be also accessed by name or number using BaseCacheMap. Advanced:
 * you can move entries between caches.
 *
 * @todo It is currently limited to some Unix systems and
 * millisecond precision time.
 *
 * For a useful example of derived classes, see @ref DirectoryCache.
 *
 * This library is early pre-alpha and is not tested yet.
 */
/*@{*/

/** Type used to represent time intervals. */
typedef int interval_type;

/** Type used to represent time moments.
 * Measured in milliseconds.
 *
 * Wraps around when adding/subtracting. */
class time_type
{
    unsigned val;
public:
    time_type () { }
    time_type (unsigned milliseconds) : val (milliseconds) { }
    time_type operator + (interval_type diff) const { return val + (unsigned)diff; }
    time_type operator += (interval_type diff) { return val += (unsigned)diff; }
    time_type operator - (interval_type diff) const { return val + (unsigned)-diff; }
    time_type operator -= (interval_type diff) { return val += (unsigned)-diff; }
    friend inline interval_type operator - (time_type a, time_type b);
    friend inline bool operator < (time_type a, time_type b);
};

/** Gets current time. */
time_type get_current_time ();

class BaseBaseCacheEntry;

/** Actual caching is done by this class.
 * Entry keys can be mapped to entries in this cache by BaseCacheMap.
 * Normally you should not use this class directly, but through BaseCacheMap instead.
 *
 * Entries can be locked. Locked entries are not invalidated when they are
 * expired, until they are unlocked. Currently locked entries are not reference
 * counted.
 * @todo Documentation group for locked entries.
 * @todo No reason to allocate entries dynamically, we can use template instead.
 *  We could add @c pointer_type as template argument.
 * @todo Could be done a little faster using entry references instead of iterators.
 * @todo Document details of locking and invalidation.
 */
class BaseCache
{
    friend class BaseBaseCacheEntry;

    /** Using @c std::list warrants that iterators are not invalidated.
     * @todo However @c std::list is not the most efficient.
     *  It would be faster to use @c std::deque (or directly @c std::vector)
     * with relative overflow-wrapping positions instead of iterators. */
    typedef std::list<BaseBaseCacheEntry*> the_list_t;
    the_list_t the_list; //*< sorted from oldest to newest

    /** Entries after this are valid,
     * Entries before this are either invalid or expired but locked. */
    the_list_t::iterator valid_iter;

protected: // not private for Doxygen
    /**
     * @ingroup AbstractCache
     * @todo This iterator has the deficiency that it can't represent @c NULL.
     *   So as we sometimes need to extend iterator to hold @c NULL maybe it
     *   Would be better to hold iterator in BaseCacheEntry itself.
     *   Ideally we could have derived iterator class having is_null() method.
     * @todo Because it is not really an iterator (rename this class to @c reference?)
     *   It could be better to hold a pointer to the list element instead.
     *   This way we can add is_null() method.
     * @todo Current implementation is inefficient. Need our own container
     *   implementation instead of @c std::list, to effectively store null.
     */
    template<typename Iter, typename Element> class base_iterator
    {
        template<typename Iter2, typename Element2> // FIXME
        friend inline bool operator == (const BaseCache::base_iterator<Iter2, Element2> &a,
                                        const BaseCache::base_iterator<Iter2, Element2> &b);
    protected:
        Iter _base;
        bool null;
        base_iterator (Iter base) : _base (base) { } // hack
    public:
        base_iterator () { }
        base_iterator (int n) {
            assert (n == 0);
            null = true;
        }
        base_iterator (const base_iterator &i) : _base (i._base), null (i.null) { }

        operator bool () { return !null; }
        bool operator ! () { return null; }
        //base_iterator operator ++ () { ++_base; return *this; }

        Element &operator * () const { return **_base; }
        Element *operator -> () const { return *_base; }

        bool is_null () { return null; }
        bool reset () { return null = true; }

        BaseCache &get_cache () const { return (*this)->get_cache (); }

        /**
         * @todo Remove this function? */
        bool is_locked () const { return (*this)->ref_count != 0; }

        /** Returns @c false is entry has expired.
         * Expired entry may continue to be valid if it is locked. 
         * To check whether an entry is valid use is_valid() method. */
        bool is_expired (time_type time = get_current_time ()) const {
            return end_time () < time;
        }

        /** Returns @c false is entry has expired and is not locked. */
        bool is_valid (time_type time = get_current_time ()) const {
            return is_locked () || is_expired (time);
        }

        /** @brief The initial time from which entry timeout is counted
         * (normally the time when entry was added). */
        time_type start_time () const { return (*this)->_start_time; }

        /** When the entry expires (provided that it is unlocked). */
        time_type end_time () const {
            return (*this)->_start_time + get_cache ().timeout ();
        }
    };

    template<typename Iter2, typename Element2>
    friend inline bool operator == (const BaseCache::base_iterator<Iter2, Element2> &a,
                                    const BaseCache::base_iterator<Iter2, Element2> &b);

public:
    /**
     * @ingroup AbstractCache
     * @bug What should be value types of these iterators? */
    class const_iterator:
        // I use a typedef name as argument for a bug of Doxygen 1.3.8
        public base_iterator<the_list_t::const_iterator, const BaseBaseCacheEntry>
    {
        typedef base_iterator<the_list_t::const_iterator, const BaseBaseCacheEntry> base_class;
        friend class BaseCache;
        const_iterator (the_list_t::const_iterator base) : base_class (base) { } // hack
    public:
        const_iterator () : base_class () { }
        const_iterator (int n) : base_class (n) { }
        const_iterator (const const_iterator &i) : base_class (i) { }
    };

    /** Represents references to entries of a BaseCache.
     * Strictly speaking it is not an iterator because it does not have
     * <code>++</code> operator.
     * @ingroup AbstractCache */
    class iterator:
        // I use a typedef name as argument for a bug of Doxygen 1.3.8
        public base_iterator<the_list_t::iterator, BaseBaseCacheEntry>
    {
        typedef base_iterator<the_list_t::iterator, BaseBaseCacheEntry> base_class;
        friend class BaseCache;
        friend class BaseBaseCacheEntry;
        iterator (the_list_t::iterator base) : base_class (base) { } // hack
    public:
        iterator () : base_class () { }
        iterator (int n) : base_class (n) { }
        iterator (const iterator &i) : base_class (i) { }

        /** Removes the entry from the BaseCache object.
         * This function only removes the entry from BaseCache and does nothing
         * other (i.e. does not call <code>delete</code> operator).
         */
        void do_remove_entry ();

        /** Removes a cache entry.
         * In derived classes it may instead move entry to an other queue
         * (or reinsert it in the same queue). See do_invalidate() virtual method.
         */
        void invalidate ();

        //        /** Locked entries never expire.
        //         * Unlocking an expired entry destroys it (and invalidates the iterator). */
        //        void set_locked (bool locked, time_type time = get_current_time ());

        /** Lock an entry.
         * Locked entries never expire.
         * Locking is reference counted.
         *
         * Current version supports maximum 255 locks per cache entry.
         */
        void lock ();

        /** Unlock an entry.
         * Locking is reference counted.
         * An entry is invalidated (removed) when it is both unlocked and expired.
         *
         * Consider using of @ref BaseCache::EntryUnlocker or @ref BaseCache::EntryLocker
         * class instead of this function (for exception safety). */
        void unlock (time_type time = get_current_time ());
    };

    /** Destroys all entries. */
    virtual ~BaseCache () { clear (); }

    /** Destroys all entries. */
    void clear ();

    /** Adds a cache entry to the cache.
     * Returns the position at which entry is inserted.
     *
     * Returns end() if entry was not added (if it has already expired). In
     * this case the entry is automatically destroyed by operator @c delete.
     * @bug Or it should be instead invalidated?
     *
     * If @c locked is true, then entry is always added.
     * (<code>locked == true</code> implies that return value is not end().)
     *
     * Entry's start time must be not less than of existing entries.
     * @a entry should be allocated by operator @c new.
     * @a start_time the initial time from which entry timeout is counted.
     * @a ref_count Initial reference count (most often 0 or 1).
     * @todo replace @c locked with ref. counting.
     */
    iterator add_entry (BaseBaseCacheEntry *entry, unsigned ref_count, time_type time = get_current_time ());

    virtual interval_type timeout () const = 0;

#if 0
    /** Intentionally no corresponding begin(). */
    iterator end () { return iterator (the_list.end ()); } // FIXME

    /** Intentionally no corresponding begin(). */
    const_iterator end () const { return const_iterator (the_list.end ()); }
#endif // 0

    /** Removes all entries which are expired and not locked.
     * Useful only to free memory, as invalidating is anyway done automatically. */
    void invalidate_old (time_type time = get_current_time ());

    /** This class unlock an entry on destruction.
     * @ingroup AbstractCache */
    class EntryUnlocker
    {
        iterator _i;
        EntryUnlocker (const EntryUnlocker &); // private
    public:
        /** Constructor. */
        EntryUnlocker (iterator i) : _i (i) { }
        ~EntryUnlocker () { _i.unlock (); }
    };

    /** This class holds a reference to an entry.
     * That is it locks an entry on construction an unlocks it on destruction.
     * @ingroup AbstractCache */
    class EntryLocker: public EntryUnlocker
    {
    public:
        /** Constructor. */
        EntryLocker (iterator i) : EntryUnlocker (i) { i.lock (); }
    };
};

/** Do not use this class directly, use MappedCacheEntry template instead.
 * @todo What about partial entry invalidation, e.g. when after a timeout
 *   directory listing is to be counted incomplete (as new files may be created)]
 */
class BaseBaseCacheEntry
{
    friend class BaseCache; // to be able to destroy

    template<typename Iter, typename Element>
    friend class BaseCache::base_iterator;

    friend bool operator < (const BaseBaseCacheEntry &a, const BaseBaseCacheEntry &b);

private:
    time_type _start_time;
#ifdef DEBUG
    bool added :1;
#endif // DEBUG
    unsigned char ref_count;
private:
    /** Private copy constructor warrants that pointer based comparison will be not broken. */
    BaseBaseCacheEntry (const BaseBaseCacheEntry &);
protected:
    virtual ~BaseBaseCacheEntry () { //*< Protected for no destruction without proper removal
        //#ifdef DEBUG
        //        assert (added); // See also BaseCache::add_entry()
        //#endif
    }

protected:
    /** Method used to invalidate an entry (when it expires).
     * This class implementation calls <code>delete this;</code>.
     * Derived classes may do something other (e.g. to add the entry into
     * the same or other event queue again).
     *
     * This method is called immediately before removal an entry from the BaseCache
     * (e.g. when the entry becomes invalid).
     * If this method returns @c true the entry should be removed with operator
     * @c delete when it becomes invalid. Otherwise the entry is not destroyed.
     * @todo Specify whether this method should be called when destructing a BaseCache object.
     * @todo Is iterator argument needed?
     */
    void do_invalidate ();

    friend class BaseCache::iterator;

public:
    /** Creates a cache entry.
     * The created entry is added to the cache object.
     *
     * Entry should be allocated by operator @c new.
     * <!-- After constructor should be called init() method.
     * So a way to create an entry is
     * @code new EntryClass() -> init(false); @endcode
     *
     * See init() documentation for details about return value of the above construct. -->
     * @bug Where should be passed ref. count, here or in add_entry()?
     */
    BaseBaseCacheEntry ()
#ifdef DEBUG
        : added (false), ref_count (0)
#else
        : ref_count (0)
#endif
    { }

    /** The cache to which this entry belows.
     * Derived classes of this normally should have a static member of class
     * BaseCache (or alternatively BaseCache dynamically allocated when needed).
     * In derived classes this function should normally return reference to
     * such a static member.
     *
     * Note that I use virtual function instead of member variable to save memory.
     * @todo Indeed add derived with such member variable.
     */
    virtual BaseCache &get_cache () const = 0;
};

/** Base class for cache entries based on timeout.
 * You should not use this class directly but use MappedCacheEntry instead
 * for correct removal of entries from cache maps.
 *
 * To every entry is associated a key value (e.g. entry number or name).
 * Key is used for accessing entries in BaseCacheMap.
 *
 * Do not call @c delete operator on pointers to objects of this class.
 * Use BaseCache::remove_entry() instead.
 * @todo Should be integrated with BaseCache for efficient allocation
 * @todo Should automatically prolong on access.
 */
template<class Key>
class BaseCacheEntry: public BaseBaseCacheEntry
{
private:
    Key _key;
public:
    BaseCacheEntry (const Key &key) : BaseBaseCacheEntry (), _key (key) { }
    Key get_key () { return _key; }
};

/** @internal
 * @todo Seems unneeded. Remove? */
inline bool operator == (const BaseBaseCacheEntry &a, const BaseBaseCacheEntry &b)
{
    return &a == &b; // all cache entries in a set are distinct
}

/** @internal
 * @todo This would be not linear ordering at big time periods because time wraps around.
 * @todo Seems unneeded. Remove? */
inline bool operator < (const BaseBaseCacheEntry &a, const BaseBaseCacheEntry &b)
{
    if (a._start_time < b._start_time) return false;
    // Fallback:
#if INTBITS >= PTRBITS // Could use C99 instead
    return (int)(void*)&a < (int)(void*)&b;
#elif LONGBITS >= PTRBITS
    return (long)(void*)&a < (long)(void*)&b;
#else
#  error "long" type too small for a pointer
#endif
}

template<typename Key> class MappedCacheEntry;

/** Maps from keys to cache entries.
 * Destruction of this object destroys all entries it holds.
 * @bug Remove this class at all? Use @c std::map instead?
 * @todo Shouldn't we have base class whose destructor does not destroy entries? */
template<typename Key> class BaseCacheMap
{
    friend class MappedCacheEntry<Key>;
    typedef BaseCacheEntry<Key> entry_type;
public: // FIXME should be private
    /** This uses the property of BaseCache that its iterators are not invalidated
     * until corresponding entries are destroyed. */
    typedef std::map<Key, BaseCache::iterator> the_map_t;
    the_map_t the_map;
public:
    BaseCacheMap () { }
    ~BaseCacheMap () { purge_entries (); }

    // TODO: Iterator

    /** Swaps two cache maps.
     * That is it makes the content of the first cache map second and second first.
     *
     * It can be used for efficient in-place cache modification.
     * For example, it is used in directory listing refilling implementation. */
    void swap (BaseCacheMap &second) { the_map.swap (second.the_map); }

    /** Returns NULL if no such key. */
    BaseBaseCacheEntry *get_entry (const Key &key);

    /**
     * @todo Integrate it with get_entry(). Probably change API here. */
    bool get_cache_iterator (const Key &key, BaseCache::iterator &iter) {
        const typename the_map_t::const_iterator i = the_map.find (key);
        const bool found = i != the_map.end ();
        if (found) {
            iter = i->second;
            iter->get_cache ().invalidate_old (); // warrants that we do not get old entry
        }
        return found;
    }

    //BaseCache::iterator end () { return }

    /**
     * @todo Return value of from <code>the_map.erase (key)</code>. */
    void remove_entry (const Key &key) { (void)the_map.erase (key); }

    /**
     * @todo Return value of from <code>the_map.erase (key)</code>. */
    void remove_entry (entry_type *entry) { remove_entry (entry->get_key ()); }

    /** Add an entry to entry map.
     * @a entry should be allocated by new.
     *    If entry with the same key already exists it is removed.  */
    BaseCache::iterator add_entry (entry_type *entry, bool locked = false, time_type time = get_current_time ());

    /** Adds an entry to cache map.
     * Adds to cache map an entry which is already in cache.
     &
     * See also add_entry().
     */
    void do_add_entry (BaseCache::iterator it, bool locked);

    /** Releases all entries.
     * References to the entries are continued to be hold in the BaseCache object. */
    void release_entries () { the_map.clear (); }

    /** Remove all entries both from this object and from BaseCache. */
    void purge_entries ();

protected:
    /** make public? */
    void remove (BaseCache::iterator i) {
        /** If the entry is derived from MappedCacheEntry,
         * this automatically removes the entry from the map. */
        the_map.erase (i->get_key ());
    }
};

/** Cache map entry automatically removed from BaseCacheMap on destruction.
 * @todo ifdef DEBUG ensure that it is added to cache map before destruction. */
template<typename Key>
class MappedCacheEntry: public BaseCacheEntry<Key>
{
    typedef BaseCacheEntry<Key> base_class;
    BaseCacheMap<Key> &_cache_map;
public:
    /** Constructor.
     * This does not actually add the entry to cache map.
     * Entry can be added to cache map by the init() method.
     *
     * Entry should be allocated by operator @c new.
     * After constructor should be called init() method.
     * So a way to create an entry is
     * @code new EntryClass(cache_map, "key") -> init(false); @endcode
     * See init() documentation for details about return value of the above construct.
     *
     * Rationale to not add entry into the cache map in constructor:
     * If a future version of this library will be designed thread safe, then
     * adding an entry in cache map in constructor would render it added in
     * cache map before it is added to BaseCache. This could break integrity
     * of cache map or require additional means to ensure the integrity.
     */
    MappedCacheEntry (BaseCacheMap<Key> &cache_map, const Key &key)
        : BaseCacheEntry<Key> (key), _cache_map (cache_map)
    { }

    //~MappedCacheEntry(); // virtual override

    void clear (); // TODO: also thibk how to preserve old entries
    BaseCacheMap<Key> &get_cache_map () { return _cache_map; }
    void do_invalidate (MappedCacheEntry<Key> *entry); // virtual override
};

/*@}*/

////////////////////////////////////////////////////////////////////////////////
///                          Implementation follows                          ///
////////////////////////////////////////////////////////////////////////////////

/// time_type members and friends ///

inline interval_type operator - (time_type a, time_type b)
{
    return signed(b.val - a.val);
}

inline bool operator < (time_type a, time_type b)
{
    return b - a < 0; // "return a.val < b.val;" is wrong because val wraps around.
}

/// BaseCache::base_iterator stuff ///

template<typename Iter2, typename Element2>
inline bool operator == (const BaseCache::base_iterator<Iter2, Element2> &a,
                         const BaseCache::base_iterator<Iter2, Element2> &b)
{
    return (a.null && b.null) || a._base == b._base;
}

///// Template definitions follow /////

/// BaseCacheMap members ///

template<typename Key>
BaseBaseCacheEntry *BaseCacheMap<Key>::get_entry (const Key &key)
{
    const typename the_map_t::const_iterator i = the_map.find (key);
    if (i == the_map.end ()) return 0;
    const BaseCache::iterator it = i->second;
    BaseBaseCacheEntry &entry = *it;
    entry.get_cache ().invalidate_old (); // warrants that we do not get old entry
    return &entry; // FIXME: entry may be invalid now
}

template<typename Key>
void BaseCacheMap<Key>::purge_entries ()
{
    // Not the most efficient
    for (typename the_map_t::const_iterator i = the_map.begin (); i != the_map.end (); ++i)
        while (!the_map.empty ())
            the_map.begin ()->second.invalidate (); // what is more efficient begin() or end() depends on STL impl.
    //the_map.clear (); // already done by previous operator
    assert (the_map.empty ());
}

/// MappedCacheEntry members (FIXME) ///

template<typename Key>
BaseCache::iterator BaseCacheMap<Key>::add_entry (entry_type *entry, bool locked, time_type time)
{
    const BaseCache::iterator it = entry->get_cache ().add_entry (entry, locked, time);
    do_add_entry (it, locked);
    return it;
}

template<typename Key>
void BaseCacheMap<Key>::do_add_entry (BaseCache::iterator it, bool locked)
{
    entry_type *entry = static_cast<entry_type*> (&*it);
    const Key &key = entry->get_key ();
    const typename the_map_t::iterator old = the_map.find (key);
    if (old != the_map.end ())
        old->second.invalidate (); // FIXME: what if old == new?
    the_map.insert (std::make_pair (key, it));
}

// No reason to make this inline because it is virtual.
template<typename Key>
void MappedCacheEntry<Key>::do_invalidate (MappedCacheEntry<Key> *entry)
{
    _cache_map.remove_entry (get_key ());
    base_class::do_invalidate ();
}

} // namespace cache

#endif // BASECACHE_HPP_
