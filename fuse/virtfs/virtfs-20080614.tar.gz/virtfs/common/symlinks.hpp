/*
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Library General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */

#ifndef FUSE_SYMLINKS_HPP_
#define FUSE_SYMLINKS_HPP_

#include "fuse.hpp"

/** FUSE++ library namespace @ingroup FUSE */
namespace FUSE
{

/** @addtogroup FUSE */
/*@{*/

template <class Filesystem> class ReadlinkProxy
{
public:
    typedef Filesystem filesystem_t;
private:
    filesystem_t &_fs;
public:
    ReadlinkProxy (filesystem_t &fs) : _fs (fs) { }

    int readlink (std::string &name) {
        const std::string str = name; // make a copy
        return readlink (str, name);
    }
    int readlink (const std::string &link, std::string &target) {
        return readlink (link.c_str (), target);
    }
    int readlink (const char *link, std::string &target);

    int readlink_abs (std::string &name) {
        const std::string str = name; // make a copy
        return readlink_abs (str, name);
    }
    int readlink_abs (const std::string &link, std::string &target);
    int readlink_abs (const char *link, std::string &target) {
        return readlink_abs (std::string (link), target);
    }

    // If the link is broken, the filename returned by
    // readlink_recursively_abs() function is unspecified.
    int readlink_recursively_abs (std::string &name);
    int readlink_recursively_abs (const std::string &link, std::string &target) {
        target = link;
        return readlink_recursively_abs (target);
    }
    int readlink_recursively_abs (const char *link, std::string &target) {
        return readlink_recursively_abs (std::string (link), target);
    }
};

// TODO: Below class should have r/o base class

/**
 * If the relevant mount option is given, symlinks are always
 * dereferenced that is are threated as hardlinks
 * (except of not being counted in links count).
 *
 * This is needed for ftpfs and similar
 * because symlinks in FTP may point outside accessible area.
 */
template <class Base>
class FilesystemDereferencingLinks: public Base
{
protected:
    bool always_dereference;
public:
    void usage (const char *prog, struct fuse_args *outargs = 0); // override
    // Inline because anyway in practice called once
    int process_options (const char *arg, int key, struct fuse_args *outargs) {
        switch (key)
        {
            case FUSE_OPT_KEY_OPT:
                if (!std::strcmp (arg, "dereference_links=0")) {
                    always_dereference = false;
                    return 0;
                }
                if (!std::strcmp (arg, "dereference_links=1")) {
                    always_dereference = true;
                    return 0;
                }
                break;
        }
        return 1;
    }
    int opt_parse (struct fuse_args &args) {
        return BaseFilesystem::opt_parse_tmpl<Base, FilesystemDereferencingLinks> (args);
    }
    Base &base_ref () { return *this; }
public:
    typedef Base base_fs_t;

    FilesystemDereferencingLinks () : always_dereference (true) { }
    FilesystemDereferencingLinks (struct fuse_args &args)
        : always_dereference (true)
    {
        (void) opt_parse (args, data, opts);
    }

    int getattr (const char *name, struct stat *st) {
        if (!always_dereference)
            return base_fs_t::getattr (name, st);
        ReadlinkProxy<base_fs_t> linkreader (base_ref ());
        std::string target = name;
        const int res = linkreader.readlink_recursively_abs (target);
        return res < 0 ? res : base_fs_t::getattr (target.c_str (), st);
    }
    int readlink (const char *name, char *buf, size_t size) {
        if (always_dereference)
            return -EINVAL;  // Is it OK to return EINVAL even if buffers are wrong?
        return base_fs_t::readlink (name, buf, size);
    }
    // In the current version this function for alway_dereference mode will
    // delete even symlinks poiintng to non-empty directories. It is not
    // conforming to POSIX but acceptable for most apps.
    int rmdir (const char *name);
    int symlink (const char *from, const char *to) {
        if (always_dereference) return -EPERM;
        return base_fs_t::symlink (from, to);
    }
    // Moving a symlink to an other dir changes its destination accordingly.
    // (This may seem superfluous as we anyway cannot do the opposite that it
    // to change symlinks to a moved file. But I indeed do this to ensure that
    // it works trasparently for the case when all symlinks are outside to
    // unchangeable files.)
    int rename (const char *oldpath, const char *newpath);
    int utime (const char *name, struct utimbuf *time)
    {
        if (!always_dereference)
            return base_fs_t::utime (name, time);
        std::string target = name;
        ReadlinkProxy<base_fs_t> linkreader (base_ref ());
        const int res = linkreader.readlink_recursively_abs (target);
        if (res < 0) return res;
        return base_fs_t::utime (target.c_str (), time);
    }
};

/*@}*/

} // namespace FUSE

///// Template definition follow /////

// TODO: Includes should be not here.

#include <vector>
#include <iostream> // for usage message (TODO: Eliminate somehow)

#ifdef HAVE_MAX_NESTED_LINKS_IN_NAMEI_H
#  include <linux/namei.h>
#endif

#ifndef MAX_NESTED_LINKS
#  define MAX_NESTED_LINKS 5
#endif

namespace FUSE /* template definitions*/
{

namespace Impl
{
    std::string remove_dup_slashes(const char *ptr); /* Replace /// -> / */
}

/// ReadlinkProxy ///

template<class Filesystem>
int ReadlinkProxy<Filesystem>::readlink (const char *link, std::string &target)
{
    for(int size = 1024/*arbitrary*/; ; size *= 2) {
        std::vector<char> vec(size);
        const int res = _fs.readlink(link, &vec.front(), size);
        if(res < 0)
            return res;
        if(res < size) {
            target = &vec.front();
            return 0;
        }
    }
}

template<class Filesystem>
int ReadlinkProxy<Filesystem>::readlink_recursively_abs (std::string &name)
{
    for(int i=0; i<MAX_NESTED_LINKS; ++i) {
        std::string newval;
        int res = readlink_abs(name, newval);
        if(res == -EINVAL) return 0;
        if(res < 0) return res;
        name = newval;
    }
    return -ELOOP;
}

template<class Filesystem>
int ReadlinkProxy<Filesystem>::readlink_abs (const std::string &link, std::string &target)
{
    const int res = readlink(link, target);
    if(res < 0 || target[0] == '/')
        return res; // TODO: What's about target.empty()?
    const std::string dir(link.begin(), link.begin() + (link.rfind('/') + 1));
    target = dir + target;
    return 0;
}

/// FilesystemDereferencingLinks ///

template<class Base>
int FilesystemDereferencingLinks<Base>::rename (const char *oldpath, const char *newpath)
{
    if(!always_dereference)
        return base_fs_t::rename(oldpath, newpath);

    const std::string newpath_str = FUSE::Impl::remove_dup_slashes(newpath);
    const std::string oldpath_str = FUSE::Impl::remove_dup_slashes(oldpath);
    // Accordingly FUSE docs, all pathes are absolute.
    const std::string newpath_dir (newpath_str.begin(),
                                   newpath_str.begin() + (newpath_str.rfind('/') + 1));
    const std::string oldpath_dir (oldpath_str.begin(),
                                   oldpath_str.begin() + (oldpath_str.rfind('/') + 1));

    // Simply call base class method if not moving to an other directory
    // (TODO: realize that xyz/../ == ./)

    if (newpath_dir == oldpath_dir)
        return base_fs_t::rename (oldpath, newpath);

    // TODO: Do we take in account all possible combinations of symlinks (and hardlinks)?
    // if oldpath_str is a prefix of newpath_str
    if (std::equal (newpath_str.begin (), newpath_str.end (), oldpath_str.begin ()))
        return -EINVAL;

    ReadlinkProxy<base_fs_t> linkreader (base_ref ());
    std::string target = oldpath;
    /* block */ {
        const int res = linkreader.readlink (target);
        if (res < 0 // not symlink
            || (!target.empty() // symlinks can't be empty but I do an extra protection against SIGSEGV
                && target[0] == '/') // absolute symlink
        )
            return base_fs_t::rename(oldpath, newpath);
    }
    // The file with name oldpath_str is a relative symlink

    /*
     * Calculate final_target which is 'target' modified accordingly
     * new path of the symlink itself.
     *
     * (We could also eliminate leading components of 'target' which are also
     * trailing components of newpath_dir, but this may be not necessary (and
     * would even more compicate the code.)
     */

    // It is necessary to compensate leading ../ in target and trailing dirs in oldpath,
    // because otherwise moving a symlink back and forward may add unlimited number
    // of ../ components.

    // This will point to the link target without some leading ../ dirs:
    std::string::const_iterator target_without_leading_up = target.begin ();

    // This will exclude components of oldpath_dir compensated by leading ../ in target:
    std::string::const_reverse_iterator oldpath_dir_effective_end (oldpath_dir.end ());
    //--oldpath_dir_effective_end; // remove trailing '/'

    // Calculate target_without_leading_up and oldpath_dir_effective_end
    for(;;) {
        if (target.end () - target_without_leading_up < 3
            || target_without_leading_up[0] != '.' || target_without_leading_up[1] != '.' || target_without_leading_up[2] != '/'
        )
            break;
        // Below "+1" is really "-1" because oldpath_dir_effective_end is reverse.
        const std::string::const_reverse_iterator new_end =
            std::find (oldpath_dir_effective_end + 1, oldpath_dir.rend (), '/');
        if(new_end == oldpath_dir.rend ()) break;
        target_without_leading_up += 3;
        oldpath_dir_effective_end = new_end;
    }

    // Now we will work with:
    // = target_without_leading_up .. target.end()
    // = oldpath_dir.begin() .. oldpath_dir_effective_end.base()
    // = newpath_dir.begin() .. newpath_dir.end()

    const std::string::size_type max_of_two_dir_lengths =
        std::max (newpath_dir.size (),
                  std::string::size_type (oldpath_dir.rend () - oldpath_dir_effective_end));
    const std::pair<std::string::const_iterator, std::string::const_iterator>
        mis = std::mismatch (newpath_dir.begin (),
                             newpath_dir.begin () + max_of_two_dir_lengths,
                             oldpath_dir.begin ());
    const std::string::const_iterator newpath_dir_mismatch = mis.first ;
    const std::string::const_iterator oldpath_dir_mismatch = mis.second;

    const int parent_count = std::count (newpath_dir_mismatch, newpath_dir.end (), '/');
    std::string prepend;
    prepend.reserve (3*parent_count + (oldpath_dir_effective_end.base () - oldpath_dir_mismatch));
    for(int i=0; i<parent_count; ++i)
        prepend += "../";

    std::copy (oldpath_dir_mismatch, oldpath_dir_effective_end.base (),
               std::back_insert_iterator<std::string> (prepend));

    // Actually modify 'target' str:
    std::string final_target = prepend;
    std::copy (target_without_leading_up, const_cast<const std::string&> (target).end (),
               std::back_insert_iterator<std::string> (final_target));

    /*
     * Do actual FS modification.
     */

    /* block */ { // If we know in advance that we can't do it, do nothing.
        // FIXME: Does this check take SUID/SGID (real vs. effective ID) into account?
        // (It is anyway NOT a security hole.)
        // TODO: .access() is not always defined.
        const int res = base_fs_t::access (oldpath_dir.c_str (), W_OK&X_OK);
        if (res) return res;
    }
    /**
     * @todo We do NOT conform to POSIX and man rename(2) here!
     * If newpath already exists it should be overwritten.
     * We can do it only by its prior removal (or else by creating
     * a symlink in an other path and them moving the symlink).
     * In both cases we cannot (in case of failure of removal of oldpath)
     * do it without generating a temporary path in the filesystem
     * (where we could store either renamed file which is to be overwritten,
     * or the temporary symlink.)
     * Strictly speaking we cannot do it because we have no formal "right"
     * to create any additional pathes.
     * However even the FUSE core does it renaming files instead of deleting them.
     * So: We have a bug in FUSE core, which however WE PROBABLY CAN WORKAROUND
     * IN C++ LEVEL by adding some additional requirements to our FS classes.
     * (Using access() is not a reliable solution because of races.)
     */
    /* block */ {
        // For performance first try symlink() without any prior checking.
        const int res = base_fs_t::symlink (final_target.c_str (), newpath); // never overwrites (instead ruturns EEXIST)
        if (res) return res;
    }
    /* block */ {
        const int res = base_fs_t::unlink (oldpath);
        if (res) // if no success...
            return base_fs_t::unlink (newpath); // ... restore things back
    }

    return 0;
}

template<class Base>
int FilesystemDereferencingLinks<Base>::rmdir (const char *name)
{
    if (!always_dereference) return base_fs_t::rmdir (name);
    struct stat st;
    const int res = this->getattr (name, &st);
    if (res < 0) return res;
    if (!S_ISDIR(st.st_mode))
        return -ENOTDIR;
    else if (st.st_nlink > 2) // We assume that the FS correctly implements st_nlink.
        return -ENOTEMPTY;   // Don't our DOS and NTFS impls. have a bug here? But they anyway don't have symlink.
    return base_fs_t::unlink (name);
}

template<class Base>
void FilesystemDereferencingLinks<Base>::usage (const char *prog, struct fuse_args *outargs)
{
    std::cerr <<
        "dereferencefs options:\n"
        "    -o dereference_links={0|1}\n"
        "                           whether to dereference symlinks\n"
        << std::endl;
    Base::usage (outargs->argv[0], outargs);
}

} // namespace FUSE

#endif // FUSE_SYMLINKS_HPP_
