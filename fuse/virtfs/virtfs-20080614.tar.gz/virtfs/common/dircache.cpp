/*
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Library General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */

#include "dircache.hpp"

#include <algorithm>
#include <functional>
#include <typeinfo> // for std::bad_cast

namespace cache
{

// Some functions better would be inline

void CommonFileDirBase::destructor (BaseFileListCache::entry_type::*BaseCache::iterator Field) // or do it in do_invalidate()?
{
    BaseFileListCache::iterator i = list.get_entry (get_key ());
    BaseFileListCache::entry_type &entry = static_cast<BaseFileListCache::entry_type&> (*i);
    entry.set (Field, BaseCache::iterator (0));
    if (!entry.file_info () && !entry.directory ())
        list.remove_entry (get_key ());
}

/// BaseBaseFileCacheEntry ///

BaseBaseFileCacheEntry::~BaseBaseFileCacheEntry ()
{
    _dir.files.erase (pos._base);
    base_class::destructor (&entry_type::file_iter);
}

void BaseBaseFileCacheEntry::delete_file (BaseCache::iterator i, time_type time)
{
    BaseBaseFileCacheEntry *entry = static_cast<BaseBaseFileCacheEntry *> (&*i);
    i.do_remove_entry ();
    entry->do_delete_file (); // FIXME
}

/// BaseFileListCache ///

void BaseFileListCache::clear ()
{
    ordered = true;
    complete = false;
    were_errors = false;
    base_class::purge_entries (); // a little not efficient // FIXME: right?
    //files.clear (); // done by previous operator
    assert (files.empty ());
}

void BaseFileListCache::delete_file (const std::string &name, time_type time = get_current_time ())
{
    the_map_t::iterator i = the_map.find (name);
    BaseBaseFileCacheEntry *deleted = do_create_deleted_file (time);
    get_deleted_files_cache ().add_entry (deleted, 0, time); // FIXME Shouldn't it be done by do_create_deleted_file()?
    entry_type *entry;
    if (i == the_map.end ()) {
        entry = new entry_type (deleted);
        add_entry (entry); // FIXME
    } else
        entry = &*i;
    entry.directory ().invalidate ();
    entry.set_file_info (do_create_deleted_file (name, time);
}

void BaseFileListCache::do_invalidate ()
{
    for(iterator i = begin (); i != end (); ++i) {
        const BaseCache::iterator dir_iter = i->dir_iter;
        if (dir_iter)
            static_cast<entry_type&> (*dir_iter).invalidate ();
        const BaseCache::iterator file_iter = i->file_iter;
        if (file_iter)
            static_cast<entry_type&> (*file_iter).invalidate ();
    }
    base_class::do_invalidate ();
}

/// BaseFileListCache::entry_type ///

void BaseFileListCache::entry_type::join (entry_type &old)
{
    if (!file_entry) {
        set_file_entry (old.file_entry);
        old.file_entry.reset ();
    }
    if (!dir_entry) {
        set_dir_entry (old.dir_entry);
        old.dir_entry.reset ();
    }
}

/// BaseFileListCache::BaseDirectoryFiller ///

// FIXME: What to do with clear?
BaseFileListCache::BaseDirectoryFiller::BaseDirectoryFiller (BaseFileListCache &dir, bool ordered)
    : _dir (dir)
{
    dir.ordered = ordered;
    saved.swap (dir);
}

BaseCache::iterator
BaseFileListCache::BaseDirectoryFiller::add_entry (BaseFileCacheEntry *entry, bool locked, time_type time)
{
    return _dir.base_class::add_entry (entry, locked, time);
}

/// BaseFileListCache::ReplaceDirectoryFiller ///

BaseFileListCache::ReplaceDirectoryFiller::ReplaceDirectoryFiller (BaseFileListCache &dir, bool ordered)
    : BaseDirectoryFiller (dir, ordered)
{
    dir.ordered = ordered;
    dir.files.clear ();
}

BaseFileListCache::ReplaceDirectoryFiller::~ReplaceDirectoryFiller ()
{
    // Thanks to do_join() is required to not return invalid iterators,
    // we may not worry here about locking entries.
    for(the_map_t::iterator i = _dir.the_map.begin (); i != _dir.the_map.end (); ++i) {
        const BaseCache::iterator i2 = i->second;
        BaseBaseFileCacheEntry *entry = static_cast<BaseBaseFileCacheEntry*> (&*i2);
        BaseCache::iterator j;
        const bool found = saved.get_cache_iterator (entry->get_key (), j);
        _dir.do_add_entry (found ? entry->join (i2, j) : i2,
                           i2.is_locked ());
    }
    saved.release_entries ();
}

BaseCache::iterator
BaseFileListCache::ReplaceDirectoryFiller::add_entry (BaseFileCacheEntry *entry, bool locked, time_type time)
{
    const BaseCache::iterator i = BaseDirectoryFiller::add_entry (entry, locked, time);
    if (!saved.get_entry (entry->get_key ()))
        _dir.files.push_back (entry);
    return i;
}

/// BaseFileListCache::AppendDirectoryFiller ///

BaseFileListCache::AppendDirectoryFiller::~AppendDirectoryFiller ()
{
    // Thanks to do_join() is required to not return invalid iterators,
    // we may not worry here about locking entries.
    for(the_map_t::iterator i = saved.the_map.begin (); i != saved.the_map.end (); ++i) {
        const BaseCache::iterator i2 = i->second;
        BaseBaseFileCacheEntry *entry = static_cast<BaseBaseFileCacheEntry*> (&*i2);
        BaseCache::iterator j;
        const bool found = saved.get_cache_iterator (entry->get_key (), j);
        BaseBaseFileCacheEntry *entry2 = static_cast<BaseBaseFileCacheEntry*> (&*j);
        _dir.do_add_entry (found ? entry2->join (j, i2) : j,
                           j.is_locked ());
    }
    saved.release_entries ();
}

/// BaseDirectoryFileCacheEntry ///

#if 0
void BaseDirectoryFileCacheEntry::do_delete_file ()
{
    for (iterator i=begin (); i!=end(); ++i)
        i.invalidate ();
    return BaseFileCacheEntry::do_delete_file ();
}

BaseCache::iterator BaseDirectoryFileCacheEntry::do_join (
    BaseCache::iterator newentry, BaseCache::iterator oldentry)
{
    BaseDirectoryFileCacheEntry *olddir;
    try {
        olddir = dynamic_cast<BaseDirectoryFileCacheEntry *> (&*oldentry);
    } catch (const std::bad_cast &) {
        goto end;
    }
    // TODO: Move below to a separate BaseFileListCache method.
    load_other_dir_content (*olddir);
end:
    oldentry.invalidate ();
    return newentry;
}
#endif // 0

} // namespace cache
