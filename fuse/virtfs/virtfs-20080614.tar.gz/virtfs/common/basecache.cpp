/*
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Library General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */

#include "basecache.hpp"

#include <unistd.h>
#include <sys/types.h>
#include <sys/time.h>

namespace cache
{

namespace Impl
{
    /** Transforms argument to wrapping around milliseconds value with some arbitrary start point. */
    time_type to_milliseconds (const struct timeval &tv)
    {
        return tv.tv_sec * 1000 + tv.tv_usec / 1000;
    }
}

/** Gets current time @todo rename */
time_type get_current_time ()
{
    struct timeval time;
    ::gettimeofday (&time, 0); // I assume this function never fails
    return Impl::to_milliseconds (time);
}

/// BaseCache members ///

BaseCache::iterator BaseCache::add_entry (BaseBaseCacheEntry *entry, unsigned ref_count, time_type time)
{
#ifdef DEBUG // ifndef NDEBUG is not enough because it doesn't warrant that 'added' is defined.
    assert (!entry->added);
#endif
    entry->_start_time = time;
    entry->ref_count = ref_count;
    assert (the_list.empty () || entry->_start_time >= the_list.back ()->_start_time);
    invalidate_old (); // warrants it doesn't grow infinitely
    if (ref_count || entry->_start_time + timeout () >= time) {
        the_list.push_back (entry);
#ifdef DEBUG
        entry->added = true;
#endif
        return iterator (the_list.rbegin ().base ());
    } else {
#ifdef DEBUG
        entry->added = true; // for assert in destructor
#endif
        delete entry;
        return iterator (0);
    }
}

void BaseCache::invalidate_old (time_type time)
{
    // Move valid_pos forward removing not locked entries by the way
    while (valid_iter != the_list.end () && const_iterator (valid_iter).end_time () >= time) {
        if (const_iterator (valid_iter).is_locked ())
            ++valid_iter;
        else {
            BaseBaseCacheEntry *entry = *valid_iter;
            valid_iter = the_list.erase (valid_iter);
#ifdef DEBUG // ifndef NDEBUG is not enough
            entry->added = false; // The invalidator may want to add it again
#endif
            entry->do_invalidate ();
        }
    }
}

void BaseCache::clear ()
{
    for (the_list_t::iterator i = the_list.begin (); i != the_list.end (); ++i)
        delete *i; // right?
}

/// BaseCache::iterator members ///

void BaseCache::iterator::lock ()
{
    assert ((*this)->ref_count < 255u);
    ++(*this)->ref_count;
}

void BaseCache::iterator::unlock (time_type time)
{
    assert ((*this)->ref_count > 0); // needed?
    if (!--(*this)->ref_count)
        invalidate ();
}

void BaseCache::iterator::do_remove_entry ()
{
    assert (!is_null ());
    BaseCache &cache = (*this)->get_cache ();
    if (cache.valid_iter == this->_base)
        cache.valid_iter = cache.the_list.erase (this->_base);
    else
        cache.the_list.erase (this->_base);
#ifdef DEBUG // ifndef NDEBUG is not enough
    (*this)->added = false; // The invalidator may want to add it again
#endif
}

void BaseCache::iterator::invalidate ()
{
    BaseBaseCacheEntry *entry = &**this;
    do_remove_entry ();
    entry->do_invalidate ();
}

#if 0
void BaseCache::iterator::set_locked (bool locked, time_type time)
{
    if (locked == (*this)->locked)
        return;
    // FIXME: Here and in other places: If time is exactly equal to entry end time, do NOT invalidate
    if (!locked && this->end_time () >= time)
        this->invalidate ();
    else
        (*this)->locked = locked;
}
#endif // 0

/// BaseBaseCacheEntry members ///

void BaseBaseCacheEntry::do_invalidate ()
{
    delete this;
}

} // namespace cache
