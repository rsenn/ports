/*
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Library General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */

#ifndef DIRCACHE_HPP_
#define DIRCACHE_HPP_

#include "basecache.hpp"

#include <string>
//#include <list>

#include "fuse.hpp" // TODO: Remove

namespace cache
{

// TODO: When a dir is destroyed all its files should be also destroyed?

/**
 * @defgroup DirectoryCache Advanced abstract directory listing cache
 * @ingroup AbstractCache
 *
 * This implements advanced caching (with timeout) of directory and
 * file info, based on @ref AbstractCache.
 *
 * Thanks to using C++ templates, it is not limited to any particular
 * format of directory and files data such as <code>struct stat</code> used by Unix
 * functions stat() and readdir()/opendir().
 *
 * This library is early pre-alpha and is not functional yet.
 *
 * @bug Invalidated dir must be simply marked incomplete (to not remove its recently accessed descendants).
 *
 * @todo we need to
 * add is_directory() method to @c file_info. (@c file_info may be <code>struct stat</code>,
 * so we either to extend it or introduce traits.)
 */
/*@{*/

// Probably some of these forward decls. may be removed.
class BaseBaseFileCacheEntry;
class BaseFileCacheEntry;
class BaseDeletedFileCacheEntry;
class BaseFileListCache;

/**
 * @todo It probably should not be derived from BaseCacheEntry because
 *   the key should be instead hold by BaseFileListCache::entry_type. */
class CommonFileDirBase: public BaseCacheEntry<std::string>
{
protected:
    /**
     * @todo Make it instead a member of BaseFileListCache::entry_type?
     */
    BaseFileListCache &_dir;
    CommonFileDirBase (BaseFileListCache &parent, const std::string &name)
        : BaseCacheEntry<std::string> (name), _dir (parent) { }
    template<typename T> void destructor (T Field); // or do it in do_invalidate()?
public:
    BaseFileListCache &get_directory () { return _dir; }
};

/** Class for caching directory content.
 *
 * <!--This class is derived from @ref cache::BaseCacheMap "BaseCacheMap<std::string>"
 *  (Doxygen 1.3.8 does not realize this.)-->
 * @todo Say about absolute vs. relative paths.
 * @todo Should introduce additional user-defined base class for root dir?
 */
class BaseFileListCache: public CommonFileDirBase//: public BaseCacheMap<std::string>
{
    typedef CommonFileDirBase base_class;

public:
    /**
     * @todo Inefficient memory management implementation.
     * @bug It should be deleted when both two iters are invalidated.
     * @ingroup DirectoryCache
     */
    class entry_type
    {
        friend class BaseFileListCache;
        friend class BaseBaseFileCacheEntry;

        //BaseBaseFileCacheEntry *file_entry;
        //BaseFileListCache *dir_entry;
        BaseCache::iterator file_iter, dir_iter;

    public:
        entry_type () {
            file_iter.reset ();
            dir_iter .reset ();
        }
        entry_type (BaseCache::iterator file)
            : file_iter (file)
        {
            dir_iter.reset ();
        }
        // TODO: allocation methods.
        BaseCache::iterator file_info () { return file_iter; }
        BaseCache::iterator directory () { return dir_iter; }
        /** @internal */
        BaseCache::iterator get (BaseCache::iterator entry_type::*p)
        {
            return this->*p;
        }
        /** @internal */
        void set (BaseCache::iterator entry_type::*p, BaseCache::iterator i)
        {
            if (this->*p) (this->*p).invalidate ();
            this->*p = i;
        }
        void set_file_info (BaseCache::iterator i) { set (&entry_type::file_iter, i); }
        void set_directory (BaseCache::iterator i) { set (&entry_type::dir_iter , i); }

        /** Joins information from an other entry.
         * join() may damage (make not valid) the old entry. */
        void join (entry_type &old);
    };

private:
    /**
     * @todo I assume that list iterators are not invalidated by addition/removal.
     * I'm not sure whether C++ std. warrants this. (I have only draft and SGI STL docs.)
     * So we probably need conditional preprocessing to work around of this.
     *
     * Note that dir list is <b>both</b> in a map and in an ordered list.
     */
    typedef std::list<entry_type> list_type; // or should be list of std::list<BaseCache::iterator>?
    list_type files;

    typedef std::map<std::string, list_type::iterator> the_map_t;
    the_map_t the_map;

    friend class BaseBaseFileCacheEntry; // needed?

    bool complete    : 1; /**< may be incomplete because of aborted network connection */
    bool ordered     : 1; /**< sometimes may be not only incomplete but even unordered */

    bool were_errors : 1;

protected: // not private to be included into the docs
    /** The base class for an iterator over the list of files.
     * @ingroup DirectoryCache */
    template<typename Iter, typename Element>
    class base_iterator
    {
        friend class BaseFileListCache; // needed?
        friend class BaseBaseFileCacheEntry; // needed?
        Iter _base;
        base_iterator (const Iter &base) : _base (base) { }
    public:
        base_iterator () { }
        base_iterator (const base_iterator &i) : _base (i._base) { }
        base_iterator operator ++ () {
            ++_base;
            return *this;
        }
        Element &operator * () const { return **_base; }
        Element *operator -> () const { return *_base; }
        bool operator == (base_iterator i) { return _base == i._base; }
        bool operator != (base_iterator i) { return _base != i._base; }
    };

public:
    /** See @ref base_iterator.
     * @ingroup DirectoryCache */
    typedef base_iterator<list_type::iterator, entry_type> iterator;

    /** See @ref base_iterator.
     * @ingroup DirectoryCache */
    typedef base_iterator<list_type::const_iterator, const entry_type> const_iterator;

    BaseFileListCache (BaseFileListCache &parent, const std::string &name)
        : base_class (parent, name), complete (false), ordered (true), were_errors (false)
    { }

    virtual ~BaseFileListCache () {
        clear ();
        base_class::destructor (&entry_type::dir_iter);
    }

    virtual BaseCache &get_deleted_files_cache () = 0;

    iterator begin () { return files.begin (); }
    iterator end   () { return files.end   (); }
    const_iterator begin () const { return files.begin (); }
    const_iterator end   () const { return files.end   (); }

    bool is_complete () { return complete; }
    bool is_ordered () { return ordered; }
    void make_disordered () { ordered = true; }

    /** This invalidates all contained file entries.  */
    void clear ();

public:
    /** Marks a file in cache as deleted.
     * Returns a deleted file object.
     *
     * It can either delete @p the file and construct a deleted file object
     * (e.g. derived from BaseDeletedFileCacheEntry) with the same name (key)
     * as of this object and then delete this object (also removing it from the
     * cache and from directory), or alternatively may change the current object
     * so that is_deleted() will return @c true.
     * @todo Return the iterator.
     */
    void delete_file (const std::string &name, time_type time = get_current_time ());

protected:
    void do_invalidate (); // virtual override
public:
#if 0
    /** Method used to delete a file.
     * This method should do all job of delete_file() method except of that
     * do_delete_file() should not create the object representing the deleted
     * file, because that object is created by do_create_deleted_file().
     *
     * This method is called after do_create_deleted_file().
     * This method normally should either call <code>delete entry;</code>.
     * It however should not delete entry if do_create_deleted_file() returns
     * modified entry instead of creating a new entry for deleted file.
     * @bug Remove this method?
     */
    virtual void do_delete_file (iterator i) = 0;
#endif // 0

protected:
    /** Creates object representing a deleted file.
     */
    virtual BaseBaseFileCacheEntry *do_create_deleted_file (const std::string &name,
                                                            time_type time = get_current_time ()) = 0;

    /** This object should be prepared before filling the directory with a list of files.
     * @ingroup DirectoryCache
     * In current version it is unspecified whether the dir listing is immediately
     * cleared and updated after inserting every file, or it is updated only
     * upon destroying the BaseDirectoryFiller object.
     * In the case if for one directory object are simultaneously created two
     * BaseDirectoryFiller objects, the behavior is undefined.
     *
     * Old entries with the same name as newly added entries are joined
     * using entry_type::join() method.
     */
    class BaseDirectoryFiller
    {
    protected:
        BaseFileListCache &_dir; //*< @internal
        the_map_t saved; //*< @internal
        bool ordered; //*< @internal
    public:
        BaseDirectoryFiller (BaseFileListCache &dir, bool ordered);

        /** Finishes re-filling a directory.
         * After calling this, the directory is updated to contain
         * new content.
         */
        ~BaseDirectoryFiller ();

        /** Add an entry to the end of a directory,
         * @a entry represents a file, should be allocated by new.
         * @a time entry reference time.
         */
        BaseCache::iterator add_entry (entry_type entry,
                                       time_type time = get_current_time ());
    };

public:
    /** This clears the dir before filling it.
     * @ingroup DirectoryCache
     */
    class ReplaceDirectoryFiller: public BaseDirectoryFiller
    {
    public:
        /* Removes all entries from the directory and prepares it to be filled again.
         * Dependently on implementation may clear the directory content or
         * delay clearing to the destructor.
         */
        ReplaceDirectoryFiller (BaseFileListCache &dir, bool ordered = true);

        ~ReplaceDirectoryFiller ();

        /** Add an entry to the end of a directory,
         * @a entry represents a file, should be allocated by new.
         * @a time entry reference time.
         */
        BaseCache::iterator add_entry (entry_type entry,
                                       time_type time = get_current_time ());
    };

    /** Append entries at the end of directory.
     * This marks the directory unordered.
     * @ingroup DirectoryCache
     */
    class AppendDirectoryFiller: public BaseDirectoryFiller
    {
    public:
        AppendDirectoryFiller (BaseFileListCache &dir, bool ordered)
            : BaseDirectoryFiller (dir, ordered)
        { }
        ~AppendDirectoryFiller ();
    };

    void mark_complete (bool complete = true) { this->complete = complete; }

    /** Were logical errors reading directory content.
     * @todo How to indicate physical errors?
     */
    bool get_were_errors () { return were_errors; }

    void notify_error () { were_errors = true; }

    // TODO: Hide superfluos public methods of base classes?
};

/** Common base for BaseFileCacheEntry and BaseDeletedFileCacheEntry.
 * Note that a file is normally a member of a directory represented by BaseFileListCache.
 * Key is the last name component.
 *
 * I do not derive from MappedCacheEntry but implement removal from
 * cache maps myself, because there are different variants (i.e. with or without
 * a big cache map which lists all files by their full paths, in addition to
 * files being BaseFileListCache members.
 */
class BaseBaseFileCacheEntry: public CommonFileDirBase
{
    typedef CommonFileDirBase base_class;
    /**
     * @todo Make it a member of BaseFileListCache::entry_type? */
    BaseFileListCache::iterator pos;
public:
    BaseBaseFileCacheEntry (BaseFileListCache &dir, const std::string &name)
        : CommonFileDirBase (dir, name)
    { }
    ~BaseBaseFileCacheEntry (); // virtual override
    virtual bool is_deleted () const = 0;
public: //protected: // TODO: Make protected?
//    /** Method used to remove a deleted file from the cache.
//     * @todo Document details. */
//    virtual void do_delete_file () { delete this; } // FIXME

#if 0
    /** Joins two cache entries.
     * Joins two cache entries, @c this (new) and <code>old</code> (old)
     * and returns the iterator pointing to joined entry.
     *
     * Normally should invalidate either one (or both) of the two entries.
     *
     * The actual work is done by calling the virtual method do_join().
     *
     * The default implementation invalidates the old entry and returns the new
     * entry (that is it returns <code>this</code>).
     *
     * @par "Pre-condition" @p newentry and @p oldentry should point to objects of
     *   classes derived from BaseBaseFileCacheEntry.
     * @par "Pre-condition" <code>&*newentry == this</code>.
     */
    virtual BaseCache::iterator join(BaseCache::iterator newentry, BaseCache::iterator oldentry)
    {
#ifndef NDEBUG
        dynamic_cast<BaseBaseFileCacheEntry*> (&*oldentry);
        assert (&*newentry == this);
#endif

        return do_join (newentry, oldentry);
    }
protected:
    /** Virtual method called by join().
     * In current version this function is not allowed to return the value returned
     * from BaseCache::end() method. */
    virtual BaseCache::iterator do_join (BaseCache::iterator newentry, BaseCache::iterator oldentry) {
        oldentry.invalidate ();
        return newentry;
    }
#endif // 0
};

/** Base class to hold file "stat" (metadata) info cache.
 * @todo Present implementation of subdirs is not efficient.
 *   Instead it could use a composite object.
 * @bug BaseFileCacheEntry should be locked by subdirs.
 * @bug But no, we can't access a not expired dir list through an expired BaseFileCacheEntry.
 */
class BaseFileCacheEntry: public BaseBaseFileCacheEntry
{
    typedef BaseBaseFileCacheEntry base_class;
public:
    BaseFileCacheEntry (BaseFileListCache &dir, const std::string &name)
        : base_class (dir, name)
    { }

    ~BaseFileCacheEntry () {
        get_directory ().mark_complete (false); // FIXME not in the case of delete_file()
    }

    bool is_deleted () const { return false; } // virtual override
};

#if 0
/** Cache entry for directory files.
 * For reasons of virtual inheritance see BaseFileWithInodeCacheEntry.
 */
class BaseDirectoryFileCacheEntry: virtual public BaseFileListCache,
            virtual public BaseFileCacheEntry
{
    BaseDirectoryFileCacheEntry (BaseFileListCache &dir, const std::string &name)
            : BaseFileCacheEntry (dir, name) { }
//protected: // virtual overrides:
//    void do_delete_file ();

#if 0
    /** Virtual override of do_join().
     * It copies the dir listing from the old entry to the new entry.
     * The old entry is invalidated (removed from the cache).
     * @todo Say what is done with old dir listing in newentry (if any).
     *  Or it should be required to be empty before calling this function?
     */
    BaseCache::iterator do_join (BaseCache::iterator newentry, BaseCache::iterator oldentry);
#endif // 0
};
#endif // 0

/*
 * @bug This class should have special cache? (for get_cache() to not be abstract) or what to do?
 */
template<class FileInfo>
class FileCacheEntry: virtual public BaseFileCacheEntry
{
public:
    typedef FileInfo file_info_t;
    file_info_t info;
    FileCacheEntry (BaseFileListCache &dir, const std::string &name)
        : BaseFileCacheEntry (dir, name)
    { }
};

/** Represents a deleted file.
 * That is an object of this class is a mark signifying
 * "File with that name is deleted".
 *
 * To represent a deleted file you can use either a class derived from this
 * class or a class derived directly from BaseBaseFileCacheEntry (with overriden
 * to return @c true is_deleted() method.)
 */
class BaseDeletedFileCacheEntry: public BaseBaseFileCacheEntry
{
public:
    BaseDeletedFileCacheEntry (BaseFileListCache &dir, const std::string &name)
        : BaseBaseFileCacheEntry (dir, name)
    { }
    bool is_deleted () const { return true; } // virtual override
};

/**
 * @todo Have a base class for reference counting?
 */
class BaseInodeCacheEntry
{
    ino_t _num;
    unsigned _ref_count; //*< unrelated with hardlinks count
    //bool deleted;
public:
    /** Constructor.
     * @a known_links may or may not include one additional link
        from inode cache in addition to links from file cache.
    */
    BaseInodeCacheEntry (ino_t num, unsigned known_links)
        : _num (num), _ref_count (known_links) //, deleted (false)
    { }
    virtual ~BaseInodeCacheEntry () { }
    void add_ref () { ++_ref_count; }
    /** Must be called only upon removal of corresponding BaseFileCacheEntry. */
    void release () {
        if(--_ref_count) delete this;
    }
    //bool is_deleted () const { return deleted; }
    //void set_deleted (bool deleted) { this->deleted = deleted; }
    ino_t get_inum () { return _num; }
};

/** Class to hold file "stat" (metatadata) cache based on file number (inode).
 * Note that if you have file number (inode, inum), it does not necessarily
 * means that you should use this class. You may indeed choose instead
 * directly use BaseFileCacheEntry, if performance gain of not duplicating
 * stat requests for files with multiple hardlinks is not important for you.
 * @bug inum to cache entry map is missing. So this class is not functional now.
 *
 * I use virtual inheritance because one may want a class derived from both
 * BaseFileWithInodeCacheEntry and a directory.
 * @todo Is <code>virtual</code> efficient? How could be made more efficient?
 *   with templates?
 * @bug How about the template @ref FileCacheEntry<>?
 */
class BaseFileWithInodeCacheEntry: virtual public BaseFileCacheEntry
{
    BaseInodeCacheEntry &inode;
public:
    BaseFileWithInodeCacheEntry (BaseFileListCache &dir,
                                 const std::string &name,
                                 BaseInodeCacheEntry &node,
                                 time_type end_time)
        : BaseFileCacheEntry (dir, name), inode (node)
    {
        inode.add_ref ();
    }
    ~BaseFileWithInodeCacheEntry () { inode.release (); }
    BaseInodeCacheEntry &get_inode () { return inode; }
    ino_t get_inum () { return get_inode ().get_inum (); }
};

/** Cached directory listing reader.
 * @bug Should add and lock the entry for directory itself.
 * @todo Save several bytes using @c union.
 * @todo Should be independent of @ref FUSE.
 * @bug Support for BaseFileWithInodeCacheEntry.
 */
template<typename FileInfo>
class CachedDirectoryReader: public FUSE::DirectoryReader<FileInfo>
{
    // Having duplicate base_class and base_type is intentional.
    typedef FUSE::DirectoryReader<FileInfo> base_class;
    typedef FUSE::DirectoryReader<FileInfo> base_type;

    std::auto_ptr<base_type> base_reader; // replace with simple pointer.
    char filler_place[sizeof (ReplaceDirectoryFiller)];
    BaseFileListCache::ReplaceDirectoryFiller &filler () {
        return *reinterpret_cast<BaseFileListCache::ReplaceDirectoryFiller*> (filler_place);
    }
    bool cached;
public:
    typedef FileInfo file_info;
    typedef FileCacheEntry<file_info> cache_entry_t;
private:
    typename cache_entry_t::iterator iter;
    time_type _time;
    typedef BaseFileListCache directory_type;
    directory_type *direntry;
public:
    /**
     * @todo Pass base dir reader. In the case if use cached,
     *  it would be better to not be constructed at all. So use additional templ. arg.?
     *  Or alternatively it could be constructed by a virtual function?
     */
    CachedDirectoryReader (BaseFileListCache &parent,
                           const std::string &name,
                           time_type time = get_current_time ());

    ~CachedDirectoryReader () {
        if (!cached)
            filler ().~ReplaceDirectoryFiller ();
    }

    /** Called if no cached entry.
     * Should allocate a directory listing reader by operator @c new.
     * @todo Memory should be allocated by alloca() or like this instead of the default operator @c new, if possible.
     */
    virtual base_type *create_base_reader (BaseFileListCache &parent,
                                           const std::string &name) = 0;

    /**
     * @todo We could implement it here if we would have concrete file and dir
     *  types. It could be done having passing pointers to a cache as template args
     *  (in addition to @c FileInfo). Or we can do it even without this information
     *  simply always allocating <code>FileCacheEntry<file_info></code> and relying on placement new?
     *  However then we anyway should pass the result of is_directory() (or file_info itself)
     *  to @c new.
     */
    virtual BaseFileCacheEntry *create_cache_entry (directory_type &dir,
                                                    const file_info &info) = 0;

    // Virtual overrides:
    bool get_next (file_info &info);
    bool were_errors () { return direntry->were_errors (); }
};

/*@}*/

///// Template definitions follow /////

template<typename FileInfo>
CachedDirectoryReader<FileInfo>::CachedDirectoryReader
        (BaseFileListCache &parent, const std::string &name, time_type time)
    : _time (time)
{
    direntry = cache_map.get_entry (name);
    cached = bool (direntry);
    if (cached)
        iter = entry->begin ();
    else {
        direntry = new DirectoryCacheEntry<file_info> (cache_map, name, time); // FIXME: should have place for were_errors (add it to BaseFileListCache?)
        cache_map.add_entry (direntry, true, time); // FIXME unlock direntry
        base_reader.reset (create_base_reader (cache_map, name));
        new (filler_place) ReplaceDirectoryFiller (*direntry);
    }
}

template<typename FileInfo>
bool CachedDirectoryReader<FileInfo>::get_next (file_info &info)
{
    if (cached) {
        if (iter == direntry->end ()) return false;
        info = iter->info;
    } else {
        if (!filler ().get_next (info)) return false;
        BaseFileCacheEntry *entry = create_cache_entry (info);
        // I use the time of starting reading the listing (instead of time
        // of reading a particular file) for more reliability:
        direntry->add_entry (entry, /*locked*/false, _time);
    }
    return true;
}

} // namespace cache

#endif // DIRCACHE_HPP_
