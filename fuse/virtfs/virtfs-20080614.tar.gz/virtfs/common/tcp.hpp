/*
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Library General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */

#ifndef FUSE_TCP_HPP_
#define FUSE_TCP_HPP_

// This should be rewritten to define our (potentially multithreaded)
// TCPServer class.

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include <cassert>
#include <new>
#include <iostream>

#include <string.h>  // for strerror

#if TCP_USE_COMMONCPP
#  include <errno.h>
#  include "iostreammisc.hpp"
#endif

#if TCP_USE_COMMONCPP
#  include <cc++/socket.h>
#endif
#if TCP_USE_SKSTREAMS
#  include <skstream/skstream.h>
#  include <skstream/skserver.h>
#endif

/** TCP C++ wrapper library namespace @ingroup TCP */
namespace TCP
{

/**
 * @defgroup TCP C++ TCP library wrapper.
 *
 * Wrapper around TCP class libraries.
 *
 * Uses streambuf/iostream.
 * Supports reconnecting using connect() method.
 *
 * Can use either of the following libraries:
 * @li CommonC++
 * @li skstreams (currently not functional)
 * Supported library is configurable by --with-cxx-tcp=... option.
 *
 * This library is early alpha and may have bugs.
 */
/*@{*/

typedef int port_t;

typedef int milliseconds_t;

#ifdef TCP_USE_COMMONCPP
const milliseconds_t inf_time = TIMEOUT_INF;
#elif TCP_USE_SKSTREAMS
const milliseconds_t inf_time = 0;
#endif

//namespace { // hangs some compilers
using namespace std;
//}

#ifdef TCP_USE_COMMONCPP

class IPAddress
{
    ost::InetAddress /*InetHostAddress */ addr;
    static struct in_addr make_in_addr (unsigned long u) {
        u = ::htonl (u);
        const struct in_addr sin_addr = { u };
        return sin_addr;
    }
public:
    IPAddress () { }
    //IPAddress(const IPAddress &ip) : addr(ip.addr.getAddress()) {}
    IPAddress (unsigned long u) : addr (make_in_addr (u)) { }
    IPAddress (const struct in_addr &sin_addr) : addr (sin_addr) { }
    IPAddress (const string & str) : addr (str.c_str ()) { }
    string toString () const { return addr.getHostname (); }
    operator string () const { return toString (); }
    operator unsigned long () { return::ntohl (addr.getAddress ().s_addr); }
};

#else

class IPAddress
{
    struct in_addr sin_addr;
public:
    IPAddress () { sin_addr.s_addr = 0; }
    //IPAddress(const IPAddress &ip) : addr(ip.addr.getAddress()) {}
    IPAddress (unsigned long u) { sin_addr.s_addr = ::htonl (u); }
    IPAddress (const struct in_addr &addr) { sin_addr = addr; }
    IPAddress (const string & str) { ::inet_aton (str.c_str (), &sin_addr); }
    string toString () const { return ::inet_ntoa (sin_addr); }
    operator string () const { return toString (); }
    operator unsigned long () { return ::ntohl (sin_addr.s_addr); }
};

#endif // TCP_USE_COMMONCPP

#ifdef TCP_USE_COMMONCPP

class TCPSocket: protected ost::TCPSocket
{
    friend class tcp_streambuf;
protected:
#ifndef USE_COMMONCPP1
    TCPSocket (const ost::InetAddress &addr, port_t port)
        : ost::TCPSocket (addr, port, 1, 536)
    { }
#else
    TCPSocket (const ost::InetAddress &addr, port_t port)
        : ost::TCPSocket (addr, port, 1)
    { }
#endif
    friend class TCPStream;
public:
    int getErrorCode () { return ost::TCPSocket::getErrorNumber (); }
    string getErrorString () { return ost::TCPSocket::getErrorString (); }
};

class tcp_streambuf: public misc::streambuf_forwarder<char>
{
    typedef misc::streambuf_forwarder<char> forwarder_type;
    string _host;
    port_t _port;
    milliseconds_t _timeout;

    char cc_stream_place[sizeof (ost::TCPStream)];
    ost::TCPStream &cc_stream () {
        assert (get_base_stream ());
        return *(ost::TCPStream *) cc_stream_place;
    }
    void cc_stream_destroy () {
        if (!get_base_stream ()) return;
        // This sync() duplicates sync() in disconnect() but this is not much work.
        cc_stream ().sync (); // to be sure of no exceptions in destructor
        cc_stream ().~TCPStream ();
        //delete(cc_stream_place) cc_stream();
        release_base_stream ();
    }
    void setup_base_stream() {
        set_base_stream ((ost::TCPStream *) cc_stream_place);
        if (!cc_stream ().isActive ())
            throw std::ios_base::failure ("Cannot connect"); // exceptions isn't the fastest; invent something
        //cc_stream ().setError (true); // using exceptions is not the fastest
    }
public:
    tcp_streambuf (milliseconds_t timeout = inf_time) : _timeout (timeout) { }
    tcp_streambuf (const string &host, port_t port, milliseconds_t timeout = inf_time)
        :  _host (host), _port (port), _timeout (timeout)
    {
        //connect(host, port);
    }
    tcp_streambuf (TCPSocket &socket, milliseconds_t timeout = inf_time)
        : _timeout (timeout)
    {
#ifndef USE_COMMONCPP1
        new (cc_stream_place) ost::TCPStream (socket, false, _timeout);
#else

        new (cc_stream_place) ost::TCPStream (socket, 512, false, _timeout);
#endif
        setup_base_stream();
    }
    ~tcp_streambuf () { disconnect (); }
    void connect (const string &host, port_t port) {
        _host = host;
        _port = port;
        connect ();
    }
    void connect (TCPSocket &socket) {
        if (!is_connected ()) disconnect ();
#ifndef USE_COMMONCPP1
        new (cc_stream_place) ost::TCPStream (socket, false, _timeout);
#else
        new (cc_stream_place) ost::TCPStream (socket, 512, false, _timeout);
#endif
        setup_base_stream();
        _host = "";
        _port = 0;  // hack!!
    }
    void connect () {
        if (!is_connected ()) disconnect ();
        assert (!_host.empty () && _port);
#ifndef USE_COMMONCPP1
        new (cc_stream_place) ost::TCPStream (ost::InetHostAddress (_host.c_str ()),
                                              _port, 536, false, _timeout);
#else
        new (cc_stream_place) ost::TCPStream (ost::InetHostAddress (_host.c_str ()),
                                              _port, 512, false, _timeout);
#endif
        setup_base_stream();
    }
    void disconnect () {
        if (!get_base_stream ()) return;
        cc_stream_destroy ();
    }

    bool is_connected () {
        return get_base_stream () && cc_stream().isActive ();
    }

    const string &host () { return _host; }
    port_t port () { return _port; }

    int getErrorCode () {
        return get_base_stream () ? cc_stream ().getErrorNumber () : ENOTCONN; // FIXME ** Is EBADF best code?
    }
    string getErrorString () {
        return get_base_stream () ? cc_stream ().getErrorString ()
                                  : string ("not connected"); // hack
    }

protected:
    // Virtual overrides (They only correct input error handling)
    std::streamsize xsgetn (char_type *s, std::streamsize n) {
        std::streamsize res = forwarder_type::xsgetn (s, n);
        throwOnRealError ();
        return res;
    }
    int_type underflow () {
        errno = 0; // workaround of bug in CommonC++ "2" 1.3.22
        const int_type res = forwarder_type::underflow ();
        throwOnRealError ();
        return res;
    }
    int_type uflow () {
        errno = 0; // workaround of bug in CommonC++ "2" 1.3.22
        const int_type res = forwarder_type::uflow ();
        throwOnRealError ();
        return res;
    }
private:
    class our_exception { };
    void throwOnRealError () {
        // In the underlying CommonC++ impl. if the error is caused by remote
        // socket shutdown, then ::read() returns 0 with no error.
        // Just getSystemError() may be not enough because error may be caused by timeout.
        if ((cc_stream ().fail () & std::ios_base::failbit)
            && cc_stream ().getErrorNumber () == ost::Socket::errInput
            && cc_stream ().getSystemError ()
        )
            throw our_exception ();
    }
};

class tcp_stream: private tcp_streambuf, public std::iostream
{
public:
    tcp_stream (milliseconds_t timeout = inf_time)
        : tcp_streambuf (timeout), std::iostream (this)
    { }
    tcp_stream (const string &host, port_t port, milliseconds_t timeout = inf_time)
        : tcp_streambuf (host, port, timeout), std::iostream (this)
    { }
    tcp_stream (TCPSocket &socket, milliseconds_t timeout = inf_time)
        : tcp_streambuf (socket, timeout), std::iostream (this)
    { }

    using tcp_streambuf::connect;
    using tcp_streambuf::disconnect;
    using tcp_streambuf::is_connected;
};

class TCPServer: public TCPSocket
{
    milliseconds_t _timeout;
public:
    //TCPServer();
    TCPServer (/*const string &host,*/ port_t port, milliseconds_t timeout = inf_time)
        : TCPSocket (ost::InetAddress (/*host*/), port), _timeout (timeout)
    { }
    bool waitConnect (IPAddress &ip, port_t &port) {
        if (!ost::TCPSocket::isPendingConnection (_timeout))
            return false;
        ost::tpport_t tport;
        const ost::InetHostAddress addr = ost::TCPSocket::getRequest (&tport);
        port = tport;
        ip = addr.getAddress ();
        return true;
    }
    void getLocal (IPAddress &ip, port_t &port) {
        ost::tpport_t tport;
        ip = ost::TCPSocket::getLocal (&tport).getAddress ();
        port = tport;
    }
    void reject () {
#ifndef USE_COMMONCPP1
        ost::TCPSocket::reject ();
#else
        ost::TCPSocket::Reject ();
#endif
    }
};

#endif // TCP_USE_COMMONCPP


// Attempt to support skstreams abandoned because these (as of skstreams 0.2.4)
// do not support timeouts for TCP servers (without using multithreading).
#ifdef TCP_USE_SKSTREAMS

class TCPSocket
{
protected:
    SOCKET_TYPE sock;
    TCPSocket () : sock (INVALID_SOCKET) { }
    TCPSocket (const TCPSocket &other) : sock (other.sock) { }
    TCPSocket (SOCKET_TYPE _sock) : sock (_sock) { }
    friend class TCPStream;
    friend class TCPServer;
public:
    // TODO: This function is missing in this base class in CommonC++ variant.
    void getLocal (IPAddress &ip, port_t &port) {
        // TODO: IPv6 support
        struct sockaddr_in addr;
        socklen_t len = sizeof (struct sockaddr_in);
        if (!::getsockname (sock, (struct sockaddr *) &addr, &len)) {
            // TODO: errno
            return;
        }
        ip = addr.sin_addr;
        port = addr.sin_port;
    }
};

class TCPStream: protected tcp_socket_stream
{
    string _host;
    port_t _port;

public:
    TCPStream (milliseconds_t timeout = inf_time) {
        tcp_socket_stream::setTimeout (timeout / 1000, timeout * 1000);
    }
    TCPStream (const string &host, port_t port, milliseconds_t timeout = inf_time)
        : _host (host), _port (port)
    {
        tcp_socket_stream::setTimeout (timeout / 1000, timeout * 1000);
        //connect(host, port);
    }
    TCPStream (TCPSocket &socket, milliseconds_t timeout = inf_time) {
        // FIXME: Infinite timeout?
        tcp_socket_stream::setTimeout (timeout / 1000, timeout * 1000);
        setSocket (socket.sock);
    }
    ~TCPStream () { disconnect (); }
    void connect (const string &host, port_t port) {
        _host = host;
        _port = port;
        connect ();
    }
    void connect (TCPSocket &socket) {
        setSocket (socket.sock);
        _host = "";
        _port = 0;  // hack!!
    }
    void connect () {
        if (isConnected ()) return;
        assert (!_host.empty () && _port);
        open (_host, _port);
    }
    void disconnect () {
        if (!isConnected ()) return;
        close ();
    }

    const string &host () { return _host; }
    port_t port () { return _port; }

    istream &in () {
        assert (isConnected ());
        return *this;
    }
    ostream &out () {
        assert (isConnected ());
        return *this;
    }

    bool isConnected () { return is_open (); }
    bool socketOK () { return is_open (); } // FIXME
    bool socketFailed () { return !is_open (); } // FIXME
    int getErrorCode () { return getLastError (); }
    string getErrorString () { return ::strerror (getErrorCode ()); }
    // This function return true if failbit is because of a serious error,
    // not just because the remote end has closed or shut down the socket:
    bool inputFailIsError () { return bad (); }
};

class TCPServer: public TCPSocket
{
    tcp_socket_server serv; // FIXME: timeout here is missing
    milliseconds_t _timeout;
public:
    // TODO: Here silly duplicating of two classes with field port. Probably mistake.
    TCPServer (/*const string &host,*/ port_t port, milliseconds_t timeout = inf_time)
        : serv (port), _timeout (timeout)
    { }
    bool waitConnect (IPAddress &ip, port_t &port) {
        TCPSocket remote = serv.accept ();
        remote.getLocal (ip, port);
        return true;
    }
    void reject () { serv.close (); } // FIXME
    // FIXME: In CommonC++ version these functions are in TCPSocket class instead
    int getErrorCode () { return serv.getLastError (); }
    string getErrorString () { return ::strerror (serv.getLastError ()); }
};
#endif // TCP_USE_SKSTREAMS

/*@}*/

}

#endif // FUSE_TCP_HPP_
