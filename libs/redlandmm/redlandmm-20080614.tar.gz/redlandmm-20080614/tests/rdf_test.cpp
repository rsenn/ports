#include <redlandmm/Model.hpp>
#include <redlandmm/Query.hpp>

int
main()
{
	return 0;
}
