stupidBot

The stupidest of IRC bots, but it does CIA echos