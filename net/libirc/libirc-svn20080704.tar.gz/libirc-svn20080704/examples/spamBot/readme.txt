spamBot

The simple spam prevention bot