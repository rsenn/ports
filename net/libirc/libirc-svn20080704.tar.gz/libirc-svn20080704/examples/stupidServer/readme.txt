stupidServer

The stupidest of IRC servers