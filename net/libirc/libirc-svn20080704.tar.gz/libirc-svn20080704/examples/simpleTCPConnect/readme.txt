SimpleTCPConnect

Simple example of using the low level TCP/IP connection class to connect to an IRC server, send a login, join a channel, and receive data.

Not the best way to do it, the full libIRC handles it better, but this is a good test of the TCP/IP classes.