SimpleIRCConnect

Sample app that shows how to use libIRC to conenct to an IRC server as a client.